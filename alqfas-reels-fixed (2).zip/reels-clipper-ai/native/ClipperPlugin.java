package com.reelsclipper.ai;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.net.Uri;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextDirectionHeuristics;
import android.text.TextPaint;
import android.os.Handler;
import android.os.Looper;

import androidx.annotation.OptIn;
import androidx.media3.common.Effect;
import androidx.media3.common.MediaItem;
import androidx.media3.common.audio.AudioProcessor;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.effect.BitmapOverlay;
import androidx.media3.effect.OverlayEffect;
import androidx.media3.effect.OverlaySettings;
import androidx.media3.effect.Presentation;
import androidx.media3.effect.TextureOverlay;
import androidx.media3.transformer.Composition;
import androidx.media3.transformer.DefaultEncoderFactory;
import androidx.media3.transformer.EditedMediaItem;
import androidx.media3.transformer.Effects;
import androidx.media3.transformer.ExportException;
import androidx.media3.transformer.ExportResult;
import androidx.media3.transformer.ProgressHolder;
import androidx.media3.transformer.Transformer;
import androidx.media3.transformer.VideoEncoderSettings;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import com.google.common.collect.ImmutableList;

import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * قص مقطع (start → end) أصلياً عبر Media3 Transformer بتسريع عتادي (أسرع بكثير من الوقت الحقيقي).
 * trim({ path, start, end, out, bitrate, maxShort }) -> { path, size }
 */
@OptIn(markerClass = UnstableApi.class)
@CapacitorPlugin(name = "Clipper")
public class ClipperPlugin extends Plugin {
    private Transformer transformer;
    private Handler main;
    private Runnable poller;

    @PluginMethod
    public void trim(final PluginCall call) {
        final String path = call.getString("path");
        final Double start = call.getDouble("start");
        final Double end = call.getDouble("end");
        final String outName = call.getString("out", "clip.mp4");
        final int bitrate = call.getInt("bitrate", 2000000);
        final int maxShort = call.getInt("maxShort", 0);
        final JSArray subs = call.getArray("subs");
        final int vw = call.getInt("vw", 0);
        final int vh = call.getInt("vh", 0);
        if (path == null || start == null || end == null || end <= start) {
            call.reject("bad args");
            return;
        }
        final File src = new File(path);
        if (!src.exists()) {
            call.reject("source missing");
            return;
        }
        File dir = new File(getContext().getCacheDir(), "clips");
        dir.mkdirs();
        final File out = new File(dir, outName);
        if (out.exists()) out.delete();

        getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    main = new Handler(Looper.getMainLooper());
                    MediaItem.ClippingConfiguration clip = new MediaItem.ClippingConfiguration.Builder()
                            .setStartPositionMs((long) (start * 1000))
                            .setEndPositionMs((long) (end * 1000))
                            .build();
                    MediaItem item = new MediaItem.Builder()
                            .setUri(Uri.fromFile(src))
                            .setClippingConfiguration(clip)
                            .build();

                    List<Effect> videoEffects = new ArrayList<>();
                    if (subs != null && subs.length() > 0 && vw > 0 && vh > 0) {
                        // الترجمة أولاً (بدقة الفيديو الأصلية) ثم تصغير الدقة إن لزم
                        SubOverlay overlay = new SubOverlay(subs, vw, vh);
                        videoEffects.add(new OverlayEffect(ImmutableList.<TextureOverlay>of(overlay)));
                    }
                    if (maxShort > 0) videoEffects.add(Presentation.createForShortSide(maxShort));
                    Effects effects = new Effects(Collections.<AudioProcessor>emptyList(), videoEffects);
                    EditedMediaItem edited = new EditedMediaItem.Builder(item).setEffects(effects).build();

                    DefaultEncoderFactory encoderFactory = new DefaultEncoderFactory.Builder(getContext())
                            .setRequestedVideoEncoderSettings(
                                    new VideoEncoderSettings.Builder().setBitrate(bitrate).build())
                            .build();

                    transformer = new Transformer.Builder(getContext())
                            .setEncoderFactory(encoderFactory)
                            .addListener(new Transformer.Listener() {
                                @Override
                                public void onCompleted(Composition composition, ExportResult result) {
                                    stopPoll();
                                    JSObject r = new JSObject();
                                    r.put("path", out.getAbsolutePath());
                                    r.put("size", out.length());
                                    call.resolve(r);
                                }

                                @Override
                                public void onError(Composition composition, ExportResult result, ExportException e) {
                                    stopPoll();
                                    call.reject("export failed: " + e.getMessage());
                                }
                            })
                            .build();
                    transformer.start(edited, out.getAbsolutePath());
                    startPoll();
                } catch (Throwable t) {
                    stopPoll();
                    call.reject("trim failed: " + t.getMessage());
                }
            }
        });
    }

    @PluginMethod
    public void cancel(PluginCall call) {
        getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try { if (transformer != null) transformer.cancel(); } catch (Throwable ignored) {}
                stopPoll();
            }
        });
        call.resolve();
    }

    private void startPoll() {
        final ProgressHolder holder = new ProgressHolder();
        poller = new Runnable() {
            @Override
            public void run() {
                if (transformer == null) return;
                int state = transformer.getProgress(holder);
                if (state != Transformer.PROGRESS_STATE_NOT_STARTED) {
                    JSObject o = new JSObject();
                    o.put("progress", holder.progress / 100.0);
                    notifyListeners("progress", o);
                }
                if (main != null) main.postDelayed(this, 250);
            }
        };
        main.postDelayed(poller, 250);
    }

    private void stopPoll() {
        if (main != null && poller != null) main.removeCallbacks(poller);
        poller = null;
    }

    /** ترجمة: نص أبيض على خلفية سوداء شفافة أسفل الفيديو (يدعم العربي والإنجليزي). */
    @OptIn(markerClass = UnstableApi.class)
    private static class SubOverlay extends BitmapOverlay {
        private final List<double[]> times = new ArrayList<>();
        private final List<String> texts = new ArrayList<>();
        private final int w, h;
        private final Bitmap blank = Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888);
        private final OverlaySettings settings = new OverlaySettings.Builder()
                .setOverlayFrameAnchor(0f, -1f)
                .setBackgroundFrameAnchor(0f, -0.80f)
                .build();
        private int lastIdx = -2;
        private Bitmap last = blank;

        SubOverlay(JSArray arr, int w, int h) {
            this.w = w;
            this.h = h;
            for (int i = 0; i < arr.length(); i++) {
                try {
                    JSONObject o = arr.getJSONObject(i);
                    times.add(new double[]{o.getDouble("s"), o.getDouble("e")});
                    texts.add(o.getString("t"));
                } catch (Exception ignored) {
                }
            }
        }

        @Override
        public Bitmap getBitmap(long presentationTimeUs) {
            double t = presentationTimeUs / 1e6;
            int idx = -1;
            for (int i = 0; i < times.size(); i++) {
                if (t >= times.get(i)[0] && t < times.get(i)[1]) { idx = i; break; }
            }
            if (idx != lastIdx) {
                lastIdx = idx;
                last = idx < 0 ? blank : render(texts.get(idx));
            }
            return last;
        }

        @Override
        public OverlaySettings getOverlaySettings(long presentationTimeUs) {
            return settings;
        }

        private Bitmap render(String text) {
            float size = Math.min(w, h) * 0.05f;
            TextPaint paint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
            paint.setColor(Color.WHITE);
            paint.setTextSize(size);
            paint.setTypeface(Typeface.DEFAULT_BOLD);
            int maxW = (int) (w * 0.88f);
            StaticLayout layout = StaticLayout.Builder.obtain(text, 0, text.length(), paint, maxW)
                    .setAlignment(Layout.Alignment.ALIGN_CENTER)
                    .setTextDirection(TextDirectionHeuristics.FIRSTSTRONG_LTR)
                    .build();
            int pad = (int) (size * 0.4f);
            int textW = 0;
            for (int i = 0; i < layout.getLineCount(); i++) {
                textW = Math.max(textW, (int) Math.ceil(layout.getLineWidth(i)));
            }
            int boxW = Math.min(maxW, textW) + pad * 2;
            int boxH = layout.getHeight() + pad;
            Bitmap bmp = Bitmap.createBitmap(boxW, boxH, Bitmap.Config.ARGB_8888);
            Canvas c = new Canvas(bmp);
            Paint bg = new Paint(Paint.ANTI_ALIAS_FLAG);
            bg.setColor(0x99000000); // أسود شفاف
            c.drawRoundRect(new RectF(0, 0, boxW, boxH), pad, pad, bg);
            c.translate((boxW - layout.getWidth()) / 2f, pad / 2f);
            layout.draw(c);
            return bmp;
        }
    }
}
