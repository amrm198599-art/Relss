// يضبط minSdk/targetSdk والتوقيع ورقم الإصدار في مشروع أندرويد المولَّد بواسطة Capacitor
import fs from 'fs';
import path from 'path';

const vp = 'android/variables.gradle';
let v = fs.readFileSync(vp, 'utf8');
v = v.replace(/minSdkVersion\s*=\s*\d+/, 'minSdkVersion = 26')
     .replace(/compileSdkVersion\s*=\s*\d+/, 'compileSdkVersion = 35')
     .replace(/targetSdkVersion\s*=\s*\d+/, 'targetSdkVersion = 35');
fs.writeFileSync(vp, v);

const gp = 'android/app/build.gradle';
let g = fs.readFileSync(gp, 'utf8');
const run = process.env.GITHUB_RUN_NUMBER || '1';
g = g.replace(/versionCode\s+\d+/, `versionCode ${run}`)
     .replace(/versionName\s+"[^"]*"/, `versionName "1.0.${run}"`);

if (!g.includes('signingConfigs')) {
  g = g.replace(/android\s*\{/, `android {
    signingConfigs {
        release {
            storeFile file("release.jks")
            storePassword System.getenv("KS_PASS")
            keyAlias System.getenv("KS_ALIAS")
            keyPassword System.getenv("KEY_PASS")
        }
    }`);
  g = g.replace(/(buildTypes\s*\{\s*release\s*\{)/, `$1
            signingConfig signingConfigs.release`);
}
fs.writeFileSync(gp, g);
const mp = 'android/app/src/main/AndroidManifest.xml';
let mf = fs.readFileSync(mp, 'utf8');
for (const perm of ['POST_NOTIFICATIONS', 'WAKE_LOCK']) {
  if (!mf.includes(perm)) mf = mf.replace('<application', `<uses-permission android:name="android.permission.${perm}" />\n    <application`);
}
if (!mf.includes('largeHeap')) mf = mf.replace('<application', '<application android:largeHeap="true"');
fs.writeFileSync(mp, mf);

// ---- قص أصلي سريع (Media3 Transformer): Plugin + تسجيله + المكتبات ----
const pkgDir = 'android/app/src/main/java/com/reelsclipper/ai';
fs.mkdirSync(pkgDir, { recursive: true });
fs.copyFileSync('native/ClipperPlugin.java', path.join(pkgDir, 'ClipperPlugin.java'));
fs.writeFileSync(path.join(pkgDir, 'MainActivity.java'), `package com.reelsclipper.ai;

import android.os.Bundle;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(ClipperPlugin.class);
        super.onCreate(savedInstanceState);
    }
}
`);
if (!g.includes('media3-transformer')) {
  g = g.replace(/dependencies\s*\{/, `dependencies {
    implementation "androidx.media3:media3-transformer:1.5.1"
    implementation "androidx.media3:media3-effect:1.5.1"
    implementation "androidx.media3:media3-common:1.5.1"`);
  fs.writeFileSync(gp, g);
}
console.log('Android configured: minSdk 26, targetSdk 35, signing injected, versionCode', run);
