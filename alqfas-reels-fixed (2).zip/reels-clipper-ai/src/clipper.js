// تصدير المقطع المحدد فقط (start → end) عبر captureStream + MediaRecorder
export async function framesAt(src, times, cb) {
  const v = document.createElement('video');
  v.muted = true; v.playsInline = true; v.preload = 'auto'; v.src = src;
  const wait = (ev) => new Promise((r) => {
    const t = setTimeout(r, 8000);
    v.addEventListener(ev, () => { clearTimeout(t); r(); }, { once: true });
  });
  await wait('loadeddata');
  for (let i = 0; i < times.length; i++) {
    v.currentTime = Math.max(0, times[i]);
    await wait('seeked');
    try {
      const c = document.createElement('canvas');
      c.width = 160; c.height = Math.round(160 * ((v.videoHeight / v.videoWidth) || 1.78));
      c.getContext('2d').drawImage(v, 0, 0, c.width, c.height);
      cb(i, c.toDataURL('image/jpeg', 0.7));
    } catch {}
  }
  v.removeAttribute('src'); v.load();
}

// opts.bitrate: معدل البت (أقل = حجم أصغر) — opts.maxShort: أقصى بُعد للضلع الأقصر (تصغير الدقة)
export function exportClip(src, startTime, endTime, onProgress, opts = {}) {
  const { bitrate = 2e6, maxShort = 0, subs = [] } = opts; // subs: توقيت مطلق من بداية الفيديو
  return new Promise((resolve, reject) => {
    const v = document.createElement('video');
    v.src = src; v.playsInline = true; v.preload = 'auto';
    v.style.cssText = 'position:fixed;bottom:0;right:0;width:96px;height:96px;opacity:0.02;pointer-events:none;z-index:-1';
    document.body.appendChild(v);
    let audioCtx = null;
    const cleanup = () => { try { audioCtx && audioCtx.close(); } catch {} try { v.pause(); } catch {} v.removeAttribute('src'); v.load(); v.remove(); };
    v.onerror = () => { cleanup(); reject(new Error('تعذر فتح الفيديو للتصدير')); };
    v.onloadedmetadata = () => { v.currentTime = startTime; };
    v.onseeked = async () => {
      v.onseeked = null;
      const cap = v.captureStream || v.mozCaptureStream;
      if (!cap || typeof MediaRecorder === 'undefined') { cleanup(); return reject(new Error('الجهاز لا يدعم التصدير')); }
      const base = cap.call(v);
      let vTracks = base.getVideoTracks(), aTracks = base.getAudioTracks();
      try { // صوت يُسجَّل بدون أن يُسمع
        const AC = window.AudioContext || window.webkitAudioContext;
        const ctx = new AC();
        const node = ctx.createMediaElementSource(v);
        const dest = ctx.createMediaStreamDestination();
        node.connect(dest);
        await ctx.resume();
        audioCtx = ctx;
        aTracks = dest.stream.getAudioTracks();
      } catch {}

      let finished = false, timer;
      const vw = v.videoWidth, vh = v.videoHeight;
      const scale = maxShort && vw && vh ? Math.min(1, maxShort / Math.min(vw, vh)) : 1;
      if (scale < 1 || subs.length) { // canvas: تصغير الدقة و/أو حرق الترجمة
        const cv = document.createElement('canvas');
        cv.width = Math.round((vw * scale) / 2) * 2; cv.height = Math.round((vh * scale) / 2) * 2;
        const g = cv.getContext('2d');
        const draw = () => {
          if (finished) return;
          try { g.drawImage(v, 0, 0, cv.width, cv.height); } catch {}
          if (subs.length) { const t = v.currentTime, c = subs.find((x) => t >= x.start && t < x.end); if (c) drawSub(g, cv.width, cv.height, c.text); }
          if (v.requestVideoFrameCallback) v.requestVideoFrameCallback(draw); else requestAnimationFrame(draw);
        };
        draw();
        vTracks = cv.captureStream(30).getVideoTracks();
      }
      const stream = new MediaStream([...vTracks, ...aTracks]);
      const mime = ['video/mp4;codecs=avc1.42E01E,mp4a.40.2', 'video/mp4', 'video/webm;codecs=vp9,opus', 'video/webm;codecs=vp8,opus', 'video/webm']
        .find((m) => MediaRecorder.isTypeSupported(m)) || '';
      const rec = new MediaRecorder(stream, { ...(mime ? { mimeType: mime } : {}), videoBitsPerSecond: bitrate, audioBitsPerSecond: 96000 });
      const chunks = [];
      rec.ondataavailable = (e) => { if (e.data && e.data.size) chunks.push(e.data); };
      rec.onstop = () => { cleanup(); resolve(new Blob(chunks, { type: rec.mimeType || mime || 'video/webm' })); };
      const finish = () => {
        if (finished) return; finished = true; clearInterval(timer);
        if (rec.state !== 'inactive') rec.stop();
      };
      timer = setInterval(() => {
        onProgress && onProgress(Math.min(1, Math.max(0, (v.currentTime - startTime) / (endTime - startTime))));
        if (v.currentTime >= endTime || v.ended) finish();
      }, 150);
      setTimeout(finish, (endTime - startTime) * 1000 + 4000);
      rec.start(500);
      try { await v.play(); } catch (e) { finish(); }
    };
  });
}

// رسم سطر الترجمة على canvas: نص أبيض + خلفية سوداء شفافة
export function drawSub(g, w, h, text) {
  if (!text) return;
  const size = Math.round(Math.min(w, h) * 0.05);
  g.font = `bold ${size}px "Noto Naskh Arabic","Noto Sans Arabic",Tahoma,Arial,sans-serif`;
  g.textAlign = 'center'; g.textBaseline = 'alphabetic';
  g.direction = /[\u0600-\u06FF]/.test(text) ? 'rtl' : 'ltr';
  const maxW = w * 0.88, lines = [];
  text.split('\n').forEach((para) => {
    let cur = '';
    para.split(/\s+/).filter(Boolean).forEach((word) => {
      const t = cur ? cur + ' ' + word : word;
      if (g.measureText(t).width > maxW && cur) { lines.push(cur); cur = word; } else cur = t;
    });
    if (cur) lines.push(cur);
  });
  if (!lines.length) return;
  const lh = size * 1.3, pad = size * 0.4;
  const bw = Math.min(maxW, Math.max(...lines.map((l) => g.measureText(l).width))) + pad * 2;
  const bh = lines.length * lh + pad;
  const x = (w - bw) / 2, y = h * 0.88 - bh;
  g.fillStyle = 'rgba(0,0,0,0.6)';
  g.beginPath();
  if (g.roundRect) g.roundRect(x, y, bw, bh, pad); else g.rect(x, y, bw, bh);
  g.fill();
  g.fillStyle = '#fff';
  lines.forEach((l, i) => g.fillText(l, w / 2, y + pad / 2 + lh * (i + 0.8)));
}
