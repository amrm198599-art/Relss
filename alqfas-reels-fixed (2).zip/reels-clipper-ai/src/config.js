// ⚠️ استخدام شخصي: ضع مفتاحك هنا. لا ترفع هذا الملف في ريبو عام.
export const GEMINI_API_KEY = 'AQ.Ab8RN6JH1Fpcvx5m-9Z02uDw2tDwH_6g0emn_mUkU8erpJEOHw';
export const GEMINI_MODEL = 'gemini-3.8-flash';
