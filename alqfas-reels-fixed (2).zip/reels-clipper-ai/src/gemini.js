import { L } from './i18n.js';
const OUT = () => (L.v === 'en' ? 'الإنجليزية (English)' : 'العربية');
const BASE = 'https://generativelanguage.googleapis.com';
const INLINE_LIMIT = 14 * 1024 * 1024;
const CHUNK = 8 * 1024 * 1024; // مضاعف 256KB
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const abortErr = () => Object.assign(new Error('أُلغي التحليل'), { name: 'AbortError' });

const SCHEMA = {
  type: 'OBJECT',
  properties: {
    clips: {
      type: 'ARRAY',
      items: {
        type: 'OBJECT',
        properties: {
          start: { type: 'NUMBER' }, end: { type: 'NUMBER' },
          title: { type: 'STRING' }, caption: { type: 'STRING' },
          hashtags: { type: 'ARRAY', items: { type: 'STRING' } },
          reason: { type: 'STRING' }
        },
        required: ['start', 'end', 'title', 'caption', 'hashtags']
      }
    }
  },
  required: ['clips']
};

const prompt = (dur) => `أنت محرر محتوى محترف للريلز والشورتس وتيك توك.
افحص الفيديو كاملاً من أول ثانية لآخر ثانية، ولا تتوقف عند عدد معين: استخرج كل المشاهد القوية (حماسية، كوميدية، مؤثرة، مفاجئة)، سواء كانت 2 أو 5 أو 6 أو أكثر حسب طول الفيديو وجودة محتواه.
قواعد التقطيع (مهمة جداً):
- قطّع حسب اكتمال المشهد والسياق وليس بمدة ثابتة: يبدأ المقطع عند بداية الموقف، ويشمل الذروة، وينتهي بعد انتهاء رد الفعل.
- ممنوع قطع نكتة أو إفيه أو جملة أو حدث في منتصفه.
- مدة المقطع بين 12 و90 ثانية، ولا تتداخل المقاطع.
- start و end بالثواني من بداية الفيديو (أرقام عشرية مسموحة).${dur ? `\n- مدة الفيديو ${Math.round(dur)} ثانية؛ لا تتجاوزها.` : ''}
لكل مقطع اكتب بلغة ${OUT()}: title عنوان جذاب قصير، caption كابشن احترافي يشد المشاهد، hashtags من 6 إلى 10 هاشتاجات متوافقة مع الترند (بدون مسافات وتبدأ بـ #)، reason سبب اختيار المقطع في جملة.`;

const toB64 = (blob) => new Promise((res, rej) => {
  const r = new FileReader();
  r.onload = () => res(String(r.result).split(',')[1]);
  r.onerror = () => rej(new Error('تعذر قراءة الفيديو'));
  r.readAsDataURL(blob);
});

function xhrSend(url, headers, body, onLoaded, signal) {
  return new Promise((res, rej) => {
    const x = new XMLHttpRequest();
    x.open('POST', url);
    for (const k in headers) x.setRequestHeader(k, headers[k]);
    x.upload.onprogress = (e) => e.lengthComputable && onLoaded && onLoaded(e.loaded);
    x.onload = () => res(x);
    x.onerror = () => rej(new Error('انقطع الاتصال'));
    x.ontimeout = () => rej(new Error('انتهت مهلة الرفع'));
    if (signal) {
      if (signal.aborted) return rej(abortErr());
      signal.addEventListener('abort', () => { x.abort(); rej(abortErr()); }, { once: true });
    }
    x.send(body);
  });
}

// ملف Gemini المرفوع يبقى صالحاً 48 ساعة: نحفظه لنكمل بدون إعادة رفع
const fileCache = {
  get(id) {
    try {
      const o = JSON.parse(localStorage.getItem('gfile:' + id) || 'null');
      return o && Date.now() - o.ts < 46 * 3600e3 ? o : null;
    } catch { return null; }
  },
  set(id, f) { try { localStorage.setItem('gfile:' + id, JSON.stringify({ ...f, ts: Date.now() })); } catch {} }
};

async function uploadFile(blob, key, { onStatus, onProgress, signal, cacheId }) {
  const mime = blob.type || 'video/mp4';
  if (cacheId) {
    const c = fileCache.get(cacheId);
    if (c) { onStatus('الفيديو مرفوع مسبقاً، نكمل التحليل…'); return c; }
  }
  onStatus('رفع الفيديو إلى Gemini…');
  const start = await fetch(`${BASE}/upload/v1beta/files`, {
    method: 'POST', signal,
    headers: {
      'x-goog-api-key': key,
      'X-Goog-Upload-Protocol': 'resumable',
      'X-Goog-Upload-Command': 'start',
      'X-Goog-Upload-Header-Content-Length': String(blob.size),
      'X-Goog-Upload-Header-Content-Type': mime,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ file: { display_name: 'video' } })
  });
  if (!start.ok) throw new Error('فشل بدء الرفع: ' + start.status);
  const url = start.headers.get('x-goog-upload-url');
  if (!url) throw new Error('تعذر الحصول على رابط الرفع');

  // رفع على أجزاء 8MB مع إعادة المحاولة: يتحمل الفيديوهات الكبيرة
  let offset = 0, last = null;
  while (offset < blob.size) {
    const end = Math.min(offset + CHUNK, blob.size);
    const final = end >= blob.size;
    const chunk = blob.slice(offset, end);
    for (let tries = 0; ; tries++) {
      try {
        const x = await xhrSend(url, {
          'X-Goog-Upload-Offset': String(offset),
          'X-Goog-Upload-Command': final ? 'upload, finalize' : 'upload'
        }, chunk, (l) => onProgress && onProgress((offset + l) / blob.size), signal);
        if (x.status < 200 || x.status >= 300) throw new Error('HTTP ' + x.status);
        if (final) last = JSON.parse(x.responseText);
        break;
      } catch (e) {
        if (e.name === 'AbortError' || tries >= 3) throw e;
        await sleep(1500 * (tries + 1));
      }
    }
    offset = end;
  }
  let f = last.file;
  onStatus('Gemini يعالج الفيديو…');
  while (f.state === 'PROCESSING') {
    await sleep(2000);
    if (signal && signal.aborted) throw abortErr();
    f = await (await fetch(`${BASE}/v1beta/${f.name}`, { headers: { 'x-goog-api-key': key }, signal })).json();
  }
  if (f.state !== 'ACTIVE') throw new Error('فشلت معالجة الفيديو');
  const info = { uri: f.uri, mimeType: f.mimeType };
  if (cacheId) fileCache.set(cacheId, info);
  return info;
}

async function mediaPart(o) {
  const { blob, youtube, key, onStatus, onProgress, signal, cacheId } = o;
  if (youtube) return { fileData: { fileUri: youtube } };
  if (blob.size <= INLINE_LIMIT) {
    onStatus('تجهيز الفيديو…');
    return { inlineData: { mimeType: blob.type || 'video/mp4', data: await toB64(blob) } };
  }
  const f = await uploadFile(blob, key, { onStatus, onProgress, signal, cacheId });
  return { fileData: { mimeType: f.mimeType, fileUri: f.uri } };
}

async function generate(parts, schema, { key, model, signal }, tools) {
  const call = async (lowRes) => {
    const gc = { temperature: 0.4 };
    if (schema) { gc.responseMimeType = 'application/json'; gc.responseSchema = schema; }
    if (lowRes) gc.mediaResolution = 'MEDIA_RESOLUTION_LOW'; // أسرع وأوفر
    const body = { contents: [{ role: 'user', parts }], generationConfig: gc };
    if (tools) body.tools = tools;
    const res = await fetch(`${BASE}/v1beta/models/${encodeURIComponent(model)}:generateContent`, {
      method: 'POST', signal,
      headers: { 'x-goog-api-key': key, 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    });
    return { res, data: await res.json() };
  };
  let { res, data } = await call(true);
  if (res.status === 400) ({ res, data } = await call(false));
  if (!res.ok) throw new Error(data?.error?.message || 'خطأ من Gemini: ' + res.status);
  const text = (data.candidates?.[0]?.content?.parts || []).map((p) => p.text || '').join('');
  const clean = text.replace(/```json|```/g, '').trim();
  try { return JSON.parse(clean); } catch {}
  const i = clean.indexOf('{'), j = clean.lastIndexOf('}');
  if (i >= 0 && j > i) { try { return JSON.parse(clean.slice(i, j + 1)); } catch {} }
  throw new Error('رد غير مفهوم من الذكاء الاصطناعي');
}

// تقطيع + وصف بالذكاء الاصطناعي (يُستخدم لروابط يوتيوب فقط)
export async function analyze(o) {
  const parts = [await mediaPart(o), { text: prompt(o.duration) }];
  o.onStatus('الذكاء الاصطناعي يحلل المشاهد…');
  o.onProgress && o.onProgress(0.95);
  const json = await generate(parts, SCHEMA, o);
  return sanitize(json.clips || [], o.duration);
}

const DESC_SCHEMA = {
  type: 'OBJECT',
  properties: {
    items: {
      type: 'ARRAY',
      items: {
        type: 'OBJECT',
        properties: {
          index: { type: 'NUMBER' }, title: { type: 'STRING' }, caption: { type: 'STRING' },
          hashtags: { type: 'ARRAY', items: { type: 'STRING' } }, reason: { type: 'STRING' }
        },
        required: ['index', 'title', 'caption', 'hashtags']
      }
    }
  },
  required: ['items']
};

// وصف المقاطع المقطّعة مسبقاً (عنوان + كابشن + هاشتاجات) بدون تغيير أوقاتها
export async function describeClips(o) {
  const list = o.clips.map((c, i) => `${i}: من ${c.start.toFixed(1)} إلى ${c.end.toFixed(1)} ثانية`).join('\n');
  const parts = [await mediaPart(o), { text: `أنت محرر محتوى محترف للريلز وتيك توك.
هذه مقاطع مقتطعة من الفيديو بالثواني (من بداية الفيديو):
${list}
شاهد كل مقطع واكتب له بلغة ${OUT()}: title عنوان جذاب قصير، caption كابشن احترافي يشد المشاهد، hashtags من 6 إلى 10 هاشتاجات متوافقة مع الترند (تبدأ بـ #)، reason سبب قوة المقطع في جملة.
لا تغيّر الأوقات ولا تضف مقاطع. أرجع عنصراً لكل index.` }];
  o.onStatus('الذكاء الاصطناعي يكتب العناوين والكابشن…');
  o.onProgress && o.onProgress(0.95);
  const json = await generate(parts, DESC_SCHEMA, o);
  return (json.items || []).map((r) => ({
    ...r, index: Math.round(+r.index),
    hashtags: (r.hashtags || []).map((h) => (h.startsWith('#') ? h : '#' + h).replace(/\s+/g, ''))
  }));
}

export function sanitize(clips, duration) {
  const out = [];
  let prevEnd = -1;
  clips
    .map((c) => ({ ...c, start: Math.max(0, +c.start || 0), end: +c.end || 0 }))
    .sort((a, b) => a.start - b.start)
    .forEach((c) => {
      if (duration) c.end = Math.min(c.end, duration);
      if (c.end - c.start < 3 || c.start < prevEnd) return;
      prevEnd = c.end;
      c.hashtags = (c.hashtags || []).map((h) => (h.startsWith('#') ? h : '#' + h).replace(/\s+/g, ''));
      out.push(c);
    });
  return out;
}


// ---- تحليل رابط: عنوان + وصف + هاشتاجات + كلمات مفتاحية ----
const META_SCHEMA = {
  type: 'OBJECT',
  properties: {
    title: { type: 'STRING' }, description: { type: 'STRING' },
    hashtags: { type: 'ARRAY', items: { type: 'STRING' } },
    keywords: { type: 'ARRAY', items: { type: 'STRING' } }
  },
  required: ['title', 'description', 'hashtags', 'keywords']
};
const metaPrompt = (what) => `أنت خبير محتوى وSEO لتيك توك وريلز ويوتيوب.
حلّل ${what} واكتب بلغة ${OUT()}:
- title: عنوان جذاب وقصير مناسب للنشر
- description: وصف احترافي من 3 إلى 5 أسطر
- hashtags: من 8 إلى 12 هاشتاج متوافق مع الترند (تبدأ بـ #، بدون مسافات)
- keywords: من 8 إلى 15 كلمة مفتاحية للبحث (بدون #)
أرجع JSON فقط بالشكل {"title":"","description":"","hashtags":[],"keywords":[]}`;

function cleanMeta(j) {
  return {
    title: String(j.title || '').trim(),
    description: String(j.description || '').trim(),
    hashtags: (j.hashtags || []).map((h) => (String(h).startsWith('#') ? String(h) : '#' + h).replace(/\s+/g, '')),
    keywords: (j.keywords || []).map((k) => String(k).replace(/^#/, '').trim()).filter(Boolean)
  };
}

// يوتيوب: يفهم الفيديو نفسه. أي رابط صفحة: يقرأ الصفحة (url_context) ثم يحلل.
export async function analyzeLink({ url, key, model, signal, onStatus }) {
  const isYT = /youtu\.?be/.test(url);
  onStatus(isYT ? 'Gemini يشاهد فيديو يوتيوب…' : 'Gemini يقرأ الرابط…');
  if (isYT) {
    const parts = [{ fileData: { fileUri: url } }, { text: metaPrompt('هذا الفيديو') }];
    return cleanMeta(await generate(parts, META_SCHEMA, { key, model, signal }));
  }
  const parts = [{ text: `${metaPrompt('محتوى هذا الرابط (صفحة أو منشور أو فيديو)')}\nالرابط: ${url}` }];
  try {
    return cleanMeta(await generate(parts, null, { key, model, signal }, [{ url_context: {} }, { google_search: {} }]));
  } catch (e) {
    if (e.name === 'AbortError') throw e;
    return cleanMeta(await generate(parts, null, { key, model, signal }, [{ url_context: {} }]));
  }
}

// فيديو محمّل: يحلل الفيديو نفسه
export async function videoMeta(o) {
  const parts = [await mediaPart(o), { text: metaPrompt('هذا الفيديو') }];
  o.onStatus('Gemini يحلل الفيديو…');
  return cleanMeta(await generate(parts, META_SCHEMA, o));
}


// ---- تلخيص الفيديو (أي مدة وأي لغة) ----
const SUM_SCHEMA = {
  type: 'OBJECT',
  properties: {
    summary: { type: 'STRING' },
    keyPoints: { type: 'ARRAY', items: { type: 'STRING' } },
    chapters: { type: 'ARRAY', items: { type: 'OBJECT', properties: { time: { type: 'STRING' }, title: { type: 'STRING' } }, required: ['time', 'title'] } },
    videoLanguage: { type: 'STRING' }
  },
  required: ['summary', 'keyPoints', 'chapters']
};
const LENS = {
  short: 'قصير: 3 إلى 4 جمل و4 نقاط رئيسية',
  medium: 'متوسط: فقرة واحدة و6 إلى 8 نقاط رئيسية',
  detailed: 'مفصل: عدة فقرات و12 إلى 15 نقطة رئيسية'
};
const langName = (o) => (o === 'src' ? 'نفس لغة الفيديو الأصلية' : o === 'en' ? 'English' : o === 'ar' ? 'العربية' : OUT());
const parseT = (t) => { const p = String(t).split(':').map(Number); return p.some(isNaN) ? 0 : p.reduce((a, x) => a * 60 + x, 0); };
const fmtT = (s) => { s = Math.max(0, Math.round(s)); const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), x = s % 60; const p = (n) => String(n).padStart(2, '0'); return (h ? h + ':' + p(m) : m) + ':' + p(x); };
const cleanSum = (j) => ({
  summary: String(j.summary || '').trim(),
  keyPoints: (j.keyPoints || []).map((x) => String(x).trim()).filter(Boolean),
  chapters: (j.chapters || []).map((c) => ({ time: String(c.time || '0:00'), title: String(c.title || '').trim() })),
  videoLanguage: String(j.videoLanguage || '')
});
const SEG = 40 * 60; // الفيديوهات الأطول تُلخَّص على أجزاء ثم تُدمج

export async function summarizeVideo(o) {
  const media = await mediaPart(o);
  const lang = langName(o.outLang), len = LENS[o.len] || LENS.medium;
  const mk = (s, e, text) => [{ ...media, ...(s != null ? { videoMetadata: { startOffset: `${s}s`, endOffset: `${e}s` } } : {}) }, { text }];
  const base = 'أنت خبير تلخيص فيديوهات. الفيديو قد يكون بأي لغة: افهمه كاملاً (الكلام والصورة) مهما كانت مدته.';
  const dur = o.duration || 0;
  if (!dur || dur <= SEG + 300) {
    o.onStatus('جارٍ تلخيص الفيديو…'); o.onProgress && o.onProgress(0.9);
    const text = `${base}\nاكتب الملخص بلغة ${lang}. الطول: ${len}.\nchapters: أهم المحاور بتوقيت time بصيغة mm:ss أو h:mm:ss من بداية الفيديو. videoLanguage: اللغة المنطوقة في الفيديو.`;
    return cleanSum(await generate(mk(null, null, text), SUM_SCHEMA, o));
  }
  const n = Math.ceil(dur / SEG), parts = [];
  for (let i = 0; i < n; i++) {
    const s = i * SEG, e = Math.min(Math.ceil(dur), (i + 1) * SEG);
    o.onStatus(`تلخيص الجزء ${i + 1} من ${n}…`); o.onProgress && o.onProgress((i + 0.3) / (n + 1));
    const text = `${base}\nهذا الجزء ${i + 1} من ${n} من فيديو طويل. لخّصه بالتفصيل بلغة ${lang}.\nتوقيتات chapters نسبية لبداية هذا الجزء فقط بصيغة mm:ss. videoLanguage: اللغة المنطوقة.`;
    parts.push({ offset: s, ...cleanSum(await generate(mk(s, e, text), SUM_SCHEMA, o)) });
  }
  o.onStatus('دمج الملخصات…'); o.onProgress && o.onProgress(n / (n + 1));
  const joined = parts.map((p, i) => ({ part: i + 1, summary: p.summary, keyPoints: p.keyPoints }));
  const text = `${base}\nهذه ملخصات أجزاء متتالية لفيديو واحد مدته ${Math.round(dur / 60)} دقيقة:\n${JSON.stringify(joined)}\nادمجها في ملخص واحد متماسك بلغة ${lang}. الطول: ${len}.\nأرجع summary وkeyPoints وvideoLanguage، واترك chapters فارغة.`;
  const r = cleanSum(await generate([{ text }], SUM_SCHEMA, o));
  r.chapters = parts.flatMap((p) => p.chapters.map((c) => ({ time: fmtT(p.offset + parseT(c.time)), title: c.title })));
  if (!r.videoLanguage) r.videoLanguage = parts[0]?.videoLanguage || '';
  return r;
}


// ---- ترجمة الكلام المنطوق إلى سطور ترجمة (subtitles) بتوقيت ----
const TR_SCHEMA = {
  type: 'OBJECT',
  properties: {
    cues: {
      type: 'ARRAY',
      items: { type: 'OBJECT', properties: { start: { type: 'NUMBER' }, end: { type: 'NUMBER' }, text: { type: 'STRING' } }, required: ['start', 'end', 'text'] }
    }
  },
  required: ['cues']
};
const TR_SEG = 600; // الفيديوهات/النطاقات الأطول تُترجم على أجزاء 10 دقائق
const DIRS = { 'ar-en': ['العربية', 'English'], 'en-ar': ['English', 'العربية'] };

function cleanCues(list, offset, segLen) {
  let cues = (list || []).map((c) => ({ start: +c.start, end: +c.end, text: String(c.text || '').trim() }))
    .filter((c) => c.text && isFinite(c.start) && isFinite(c.end));
  if (!cues.length) return [];
  // لو أرجع النموذج توقيتات مطلقة بدل النسبية لبداية الجزء
  const minS = Math.min(...cues.map((c) => c.start)), maxE = Math.max(...cues.map((c) => c.end));
  const absolute = offset > 0 && minS >= offset - 2 && maxE > segLen + 1;
  cues = cues.map((c) => ({ start: absolute ? c.start : c.start + offset, end: absolute ? c.end : c.end + offset, text: c.text }));
  return cues;
}

// ranges: [[startSec, endSec], ...]  — يرجع سطور ترجمة بتوقيت مطلق من بداية الفيديو
export async function translateRanges(o) {
  const [src, dst] = DIRS[o.dir] || DIRS['ar-en'];
  const media = await mediaPart(o);
  const segs = [];
  o.ranges.forEach(([a, b]) => { for (let s = a; s < b - 0.5; s += TR_SEG) segs.push([s, Math.min(b, s + TR_SEG)]); });
  const all = [];
  for (let i = 0; i < segs.length; i++) {
    const [s, e] = segs[i];
    o.onStatus(segs.length > 1 ? `جارٍ ترجمة الجزء ${i + 1} من ${segs.length}…` : 'جارٍ الترجمة…');
    o.onProgress && o.onProgress((i + 0.4) / segs.length);
    const text = `أنت مترجم محترف وكاتب ترجمات (subtitles) للفيديو.
استمع للكلام المنطوق في هذا المقطع (لغته ${src}) واكتب ترجمته إلى ${dst} على شكل سطور ترجمة تظهر على الشاشة.
القواعد:
- كل عنصر سطر ترجمة قصير (حتى 42 حرفاً في السطر وبحد أقصى سطرين)، ومدته بين ثانية و6 ثوانٍ ومتزامن مع الكلام، بدون تداخل بين العناصر.
- ترجمة طبيعية وواضحة بالمعنى وليست حرفية. لا تكتب وصف أصوات أو ملاحظات أو أسماء المتحدثين.
- start و end بالثواني (أرقام عشرية) نسبة لبداية هذا المقطع المُرسل (أول ثانية = 0).
- لو لا يوجد كلام أرجع قائمة فارغة.
أرجع JSON فقط.`;
    const part = { ...media, videoMetadata: { startOffset: `${s}s`, endOffset: `${e}s` } };
    const json = await generate([part, { text }], TR_SCHEMA, o);
    cleanCues(json.cues, s, e - s).forEach((c) => all.push({ ...c, start: Math.max(s, c.start), end: Math.min(e, c.end) }));
  }
  // ترتيب + منع التداخل
  all.sort((a, b) => a.start - b.start);
  const out = [];
  all.forEach((c) => {
    const prev = out[out.length - 1];
    if (prev && c.start < prev.end) prev.end = Math.max(prev.start + 0.3, c.start);
    if (c.end - c.start >= 0.3) out.push({ start: +c.start.toFixed(2), end: +c.end.toFixed(2), text: c.text });
  });
  return out;
}
