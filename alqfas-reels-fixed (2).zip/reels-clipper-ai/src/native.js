// قص سريع على أندرويد عبر Plugin أصلي (Media3 Transformer). لو مش متاح يرجع التطبيق للتصدير العادي.
import { Capacitor, registerPlugin } from '@capacitor/core';
import { Filesystem, Directory } from '@capacitor/filesystem';

const Clipper = registerPlugin('Clipper');
const CH = 3 * 1024 * 1024; // مضاعف 3 بايت => base64 سليم لكل جزء
let staged = null; // { blob, path }

const toB64 = (blob) => new Promise((res, rej) => {
  const r = new FileReader();
  r.onload = () => res(String(r.result).split(',')[1]);
  r.onerror = () => rej(new Error('تعذر قراءة الفيديو'));
  r.readAsDataURL(blob);
});

// ينسخ الفيديو مرة واحدة لمجلد الكاش ليقرأه الكود الأصلي (ويعاد استخدامه لباقي المقاطع)
async function stage(blob, onProgress) {
  if (staged && staged.blob === blob) return staged.path;
  const rel = 'src/current.mp4';
  try { await Filesystem.deleteFile({ path: rel, directory: Directory.Cache }); } catch {}
  for (let off = 0; off < blob.size; off += CH) {
    const data = await toB64(blob.slice(off, off + CH));
    if (off === 0) await Filesystem.writeFile({ path: rel, data, directory: Directory.Cache, recursive: true });
    else await Filesystem.appendFile({ path: rel, data, directory: Directory.Cache });
    onProgress && onProgress(Math.min(1, (off + CH) / blob.size));
  }
  const { uri } = await Filesystem.getUri({ path: rel, directory: Directory.Cache });
  const path = decodeURIComponent(uri.replace(/^file:\/\//, ''));
  staged = { blob, path };
  return path;
}

export const canNativeTrim = () => Capacitor.isNativePlatform();

export async function nativeTrim({ blob, start, end, name, bitrate, maxShort, subs = [], vw = 0, vh = 0, onStatus, onProgress }) {
  onStatus && onStatus('تجهيز الفيديو للقص السريع…');
  const path = await stage(blob, onProgress);
  onStatus && onStatus('جارٍ قص المقطع بسرعة…');
  onProgress && onProgress(0);
  const h = await Clipper.addListener('progress', (e) => onProgress && onProgress(Math.min(1, Math.max(0, e.progress || 0))));
  try {
    const r = await Clipper.trim({ path, start, end, out: name, bitrate, maxShort: maxShort || 0, subs, vw, vh });
    const resp = await fetch(Capacitor.convertFileSrc('file://' + r.path));
    const out = new Blob([await resp.blob()], { type: 'video/mp4' });
    try { await Filesystem.deleteFile({ path: 'clips/' + name, directory: Directory.Cache }); } catch {}
    if (!out.size) throw new Error('empty output');
    return out;
  } finally { h.remove(); }
}

// تحميل رابط فيديو مباشر بدون قيود CORS (أندرويد فقط)
export async function nativeDownload(url, onProgress) {
  const h = await Filesystem.addListener('progress', (p) => {
    if (p.contentLength > 0) onProgress && onProgress(p.bytes, p.contentLength);
  });
  try {
    const r = await Filesystem.downloadFile({ url, path: 'dl/video.tmp', directory: Directory.Cache, progress: true, recursive: true });
    const resp = await fetch(Capacitor.convertFileSrc(r.path));
    const blob = await resp.blob();
    try { await Filesystem.deleteFile({ path: 'dl/video.tmp', directory: Directory.Cache }); } catch {}
    return blob;
  } finally { h.remove(); }
}

// حفظ Blob كبير في Documents على أجزاء (بدون تحويل الملف كله لـ base64 مرة واحدة)
export async function saveBlob(blob, relPath) {
  for (let off = 0; off < blob.size; off += CH) {
    const data = await toB64(blob.slice(off, off + CH));
    if (off === 0) await Filesystem.writeFile({ path: relPath, data, directory: Directory.Documents, recursive: true });
    else await Filesystem.appendFile({ path: relPath, data, directory: Directory.Documents });
  }
}
export const nativeCancel = () => { try { return Promise.resolve(Clipper.cancel()).catch(() => {}); } catch { return Promise.resolve(); } };
