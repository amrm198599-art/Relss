import { L } from './i18n.js';
// تحليل محلي بدون إنترنت: صمت + ارتفاع الصوت + تغيّر الصورة. يشتغل مع أي حجم فيديو (بدون تحميله في الذاكرة)
const abortErrL = () => Object.assign(new Error('أُلغي التحليل'), { name: 'AbortError' });
const STEP = 0.5, MIN = 15, TARGET = 40, MAX = 75;

const TAGS_EN = ['#reels', '#tiktok', '#trending', '#explore', '#shorts', '#viral', '#fyp', '#video'];
const TAGS = ['#ريلز', '#تيك_توك', '#ترند', '#اكسبلور', '#فيديو_قصير', '#مقاطع_قصيرة', '#شورتس', '#فيرال'];

export async function localAnalyze(src, onProgress, signal) {
  const v = document.createElement('video');
  v.src = src; v.playsInline = true; v.preload = 'auto';
  v.style.cssText = 'position:fixed;bottom:0;right:0;width:96px;height:96px;opacity:0.02;pointer-events:none;z-index:-1';
  document.body.appendChild(v);
  let ctx = null;
  try {
    await new Promise((res, rej) => { v.onloadedmetadata = res; v.onerror = () => rej(new Error('تعذر قراءة الفيديو')); });
    const dur = v.duration;
    if (!isFinite(dur) || dur <= 0) throw new Error('تعذر معرفة مدة الفيديو');

    let analyser = null, buf = null;
    try { // الصوت يُحلَّل بدون أن يُسمع
      const AC = window.AudioContext || window.webkitAudioContext;
      ctx = new AC();
      const node = ctx.createMediaElementSource(v);
      analyser = ctx.createAnalyser(); analyser.fftSize = 2048;
      node.connect(analyser); await ctx.resume();
      buf = new Float32Array(analyser.fftSize);
    } catch {}

    const cv = document.createElement('canvas'); cv.width = 32; cv.height = 18;
    const g = cv.getContext('2d', { willReadFrequently: true });
    let prev = null;
    const E = [], M = [];
    v.playbackRate = 4;
    await v.play();

    await new Promise((res, rej) => {
      let lastT = -1, lastChange = Date.now();
      const iv = setInterval(() => {
        if (signal && signal.aborted) { clearInterval(iv); return rej(abortErrL()); }
        const t = v.currentTime;
        if (t !== lastT) { lastT = t; lastChange = Date.now(); }
        if (v.ended || t >= dur - 0.2 || Date.now() - lastChange > 10000) { clearInterval(iv); return res(); }
        const i = Math.floor(t / STEP);
        if (analyser) {
          analyser.getFloatTimeDomainData(buf);
          let s = 0; for (let k = 0; k < buf.length; k++) s += buf[k] * buf[k];
          E[i] = Math.max(E[i] || 0, Math.sqrt(s / buf.length));
        }
        try {
          g.drawImage(v, 0, 0, 32, 18);
          const d = g.getImageData(0, 0, 32, 18).data;
          const lum = new Float32Array(576);
          for (let k = 0; k < 576; k++) lum[k] = d[k * 4] * 0.3 + d[k * 4 + 1] * 0.59 + d[k * 4 + 2] * 0.11;
          if (prev) { let m = 0; for (let k = 0; k < 576; k++) m += Math.abs(lum[k] - prev[k]); M[i] = Math.max(M[i] || 0, m / 576); }
          prev = lum;
        } catch {}
        onProgress && onProgress(Math.min(0.98, t / dur));
      }, 100);
    });
    return segment(E, M, dur);
  } finally {
    try { v.pause(); } catch {}
    v.removeAttribute('src'); v.load(); v.remove();
    try { ctx && ctx.close(); } catch {}
  }
}

function fill(a, n) { const o = new Array(n); let p = 0; for (let i = 0; i < n; i++) { if (a[i] !== undefined) p = a[i]; o[i] = p; } return o; }

function segment(Ee, Me, dur) {
  const n = Math.max(1, Math.ceil(dur / STEP));
  const E = fill(Ee, n), M = fill(Me, n);
  const Es = new Array(n);
  for (let i = 0; i < n; i++) Es[i] = ((E[i - 1] ?? E[i]) + E[i] + (E[i + 1] ?? E[i])) / 3;
  const maxE = Math.max(...Es), maxM = Math.max(...M, 1e-6);
  const B = [];

  if (maxE > 0.003) { // فيه صوت: نقاط الصمت = حدود طبيعية للجمل
    const sorted = [...Es].sort((a, b) => a - b);
    const thr = sorted[Math.floor(n * 0.2)] * 1.5 + 0.002;
    let rs = -1;
    for (let i = 0; i <= n; i++) {
      const q = i < n && Es[i] < thr;
      if (q && rs < 0) rs = i;
      if (!q && rs >= 0) { const len = (i - rs) * STEP; if (len >= 0.8) B.push({ t: ((rs + i) / 2) * STEP, w: len }); rs = -1; }
    }
  }
  const mean = M.reduce((a, b) => a + b, 0) / n;
  const sd = Math.sqrt(M.reduce((a, b) => a + (b - mean) ** 2, 0) / n);
  M.forEach((m, i) => { if (m > mean + 2.5 * sd && m > 8) B.push({ t: i * STEP, w: 1.5 }); });
  B.sort((a, b) => a.t - b.t);

  const raw = [];
  let s = 0;
  if (dur < MIN) raw.push({ start: 0, end: dur });
  else {
    while (dur - s >= MIN) {
      let end;
      if (dur - s <= MAX) end = dur;
      else {
        const c = B.filter((b) => b.t >= s + MIN && b.t <= s + MAX);
        end = c.length
          ? c.reduce((best, b) => (b.w * 2 - Math.abs(b.t - s - TARGET) / 10 > best.w * 2 - Math.abs(best.t - s - TARGET) / 10 ? b : best)).t
          : s + TARGET;
      }
      raw.push({ start: s, end }); s = end;
    }
    if (dur - s > 0.5 && raw.length) raw[raw.length - 1].end = Math.min(dur, raw[raw.length - 1].end + (dur - s));
  }

  const avg = (arr, a, b) => { const i0 = Math.floor(a / STEP), i1 = Math.max(i0 + 1, Math.floor(b / STEP)); let t = 0; for (let i = i0; i < i1; i++) t += arr[i] || 0; return t / (i1 - i0); };
  raw.forEach((c) => { c.score = avg(Es, c.start, c.end) / (maxE || 1) + avg(M, c.start, c.end) / maxM; });
  const keep = raw.length <= 3 ? raw : [...raw].sort((a, b) => b.score - a.score).slice(0, Math.ceil(raw.length * 0.7));
  keep.sort((a, b) => a.start - b.start);
  const en = L.v === 'en';
  const GG = en ? TAGS_EN : TAGS;
  // التحليل المحلي يحدد التوقيتات فقط؛ العناوين والكابشن الحقيقية من زر التحليل بالذكاء الاصطناعي
  return keep.map((c, i) => ({
    start: +c.start.toFixed(1), end: +c.end.toFixed(1),
    title: (en ? 'Scene ' : 'مشهد ') + (i + 1),
    caption: '',
    hashtags: GG.slice(0, 4),
    reason: en ? 'Picked locally by audio and motion' : 'اختير محلياً حسب الصوت وحركة الصورة'
  }));
}
