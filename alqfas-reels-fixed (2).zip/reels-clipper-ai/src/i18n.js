// ترجمة الواجهة (عربي ⇄ English) بدون تغيير أي شيء في التصميم أو الوظائف
export const L = { v: 'ar' };
const D = {
 "ضغط: 720p متوازن": "Compress: 720p balanced",
 "ضغط: 480p حجم صغير": "Compress: 480p small",
 "ضغط: 360p أصغر حجم": "Compress: 360p smallest",
 "🗜 ضغط الفيديو كله": "🗜 Compress whole video",
 "⚙️ تشغيل متعدد": "⚙️ Multi-step run",
 "✂️ تقطيع": "✂️ Split",
 "✨ عناوين ووصف": "✨ Titles & description",
 "📝 تلخيص": "📝 Summary",
 "📤 تصدير المقاطع": "📤 Export clips",
 "🗜 ضغط الفيديو": "🗜 Compress video",
 "تحديد الكل": "Select all",
 "إلغاء التحديد": "Clear selection",
 "▶️ تشغيل الخطوات المحددة": "▶️ Run selected steps",
 "⏹ إيقاف التشغيل": "⏹ Stop run",
 "اختر فيديو أولاً": "Choose a video first",
 "اختر خطوة واحدة على الأقل": "Select at least one step",
 "تم إيقاف التشغيل": "Run stopped",
 "انتهى تشغيل الخطوات ✅": "All selected steps finished ✅",
 "جارٍ ضغط الفيديو…": "Compressing video…",
 "التصدير العادي يستغرق بقدر مدة الفيديو…": "Standard export takes as long as the video…",
 "الفيديو يحتاج ملف على الجهاز للضغط والتصدير": "Compress/export needs a video file on your device",
 "🌐 ترجمة": "🌐 Translate",
 "ترجمة: عربي → English": "Translate: Arabic → English",
 "ترجمة: English → عربي": "Translate: English → Arabic",
 "النطاق: المقطع المحدد": "Scope: selected clip",
 "النطاق: كل المقاطع": "Scope: all clips",
 "النطاق: الفيديو كله": "Scope: whole video",
 "إظهار الترجمة داخل الفيديو عند التصدير": "Burn subtitles into the exported video",
 "🗑 مسح الترجمة": "🗑 Clear subtitles",
 "الترجمة تحتاج فيديو محمّل من الجهاز": "Translation needs a video loaded from your device",
 "الترجمة تحتاج إنترنت": "Translation needs internet",
 "اختر مقطعاً أولاً (قطّع الفيديو ثم اضغط على مقطع)": "Pick a clip first (split the video, then tap a clip)",
 "⏹ إلغاء الترجمة": "⏹ Cancel translation",
 "جارٍ الترجمة…": "Translating…",
 "تم مسح الترجمة": "Subtitles cleared",
 "لا يوجد كلام يمكن ترجمته": "No speech found to translate",
 "جارٍ تصدير المقطع…": "Exporting clip…",
 "تجهيز الفيديو للقص السريع…": "Preparing video for fast export…",
 "جارٍ قص المقطع بسرعة…": "Cutting clip…",
 "القص السريع غير متاح، نستخدم التصدير العادي…": "Fast export unavailable, using standard export…",
 "القفاص ريلز": "Alqfas Reels",
 "🎬 القفاص ريلز": "🎬 Alqfas Reels",
 "اختر فيديو للبدء": "Choose a video to start",
 "📁 رفع فيديو": "📁 Upload video",
 "🔎 تحليل الرابط": "🔎 Analyze link",
 "✂️ تقطيع الفيديو إلى مشاهد": "✂️ Split video into scenes",
 "✨ تحليل بالذكاء الاصطناعي (اختياري)": "✨ AI analysis (optional)",
 "📌 معلومات الرابط": "📌 Link info",
 "العنوان": "Title",
 "الوصف": "Description",
 "الهاشتاجات": "Hashtags",
 "الكلمات المفتاحية": "Keywords",
 "📋 نسخ الكل": "📋 Copy all",
 "الكابشن": "Caption",
 "ضبط التوقيت (نصف ثانية لكل ضغطة)": "Adjust timing (0.5s per tap)",
 "البداية": "Start",
 "النهاية": "End",
 "حجم / جودة التصدير": "Export size / quality",
 "عالية (حجم أكبر)": "High (larger size)",
 "متوسطة (موصى بها)": "Medium (recommended)",
 "صغيرة جداً (أقل حجم، 480p)": "Very small (smallest size, 480p)",
 "📋 نسخ النص كامل": "📋 Copy full text",
 "💾 حفظ المقطع": "💾 Save clip",
 "⬆️ تصدير المقطع": "⬆️ Export clip",
 "سياسة الخصوصية": "Privacy policy",
 "حالة الإنترنت": "Connection status",
 "رابط فيديو مباشر أو يوتيوب": "Direct video link or YouTube",
 "مدة فيديو يوتيوب بالدقائق (اختياري)": "YouTube video length in minutes (optional)",
 "📝 تلخيص الفيديو": "📝 Summarize video",
 "📝 ملخص الفيديو": "📝 Video summary",
 "الملخص": "Summary",
 "النقاط الرئيسية": "Key points",
 "الفصول (التوقيتات)": "Chapters (timestamps)",
 "📋 نسخ الملخص": "📋 Copy summary",
 "لغة الملخص: لغة التطبيق": "Summary language: App language",
 "لغة الملخص: العربية": "Summary language: Arabic",
 "لغة الملخص: English": "Summary language: English",
 "لغة الملخص: لغة الفيديو الأصلية": "Summary language: Same as the video",
 "الطول: قصير": "Length: Short",
 "الطول: متوسط": "Length: Medium",
 "الطول: مفصل": "Length: Detailed",
 "جاهز للتقطيع": "Ready to split",
 "✂️ تقطيع بالذكاء الاصطناعي (يوتيوب)": "✂️ AI split (YouTube)",
 "رابط يوتيوب: سيتم التحليل فقط (التصدير يحتاج ملف فيديو)": "YouTube link: analysis only (export needs a video file)",
 "جارٍ تحميل الفيديو…": "Downloading video…",
 "تعذر تحميل الرابط (قد يمنعه الموقع). حمّل الفيديو وارفعه من الجهاز.": "Could not download the link (the site may block it). Download the video and upload it from your device.",
 "ضع مفتاح Gemini داخل الكود لتحليل الرابط (src/config.js)": "Put your Gemini key in the code to analyze links (src/config.js)",
 "⏹ إلغاء": "⏹ Cancel",
 "جارٍ تحليل الرابط…": "Analyzing link…",
 "تم استخراج العنوان والوصف والهاشتاجات والكلمات المفتاحية ✅": "Title, description, hashtags and keywords extracted ✅",
 "انتهى تحليل الرابط ✅": "Link analysis finished ✅",
 "المعلومات جاهزة": "Info is ready",
 "تحليل الرابط يحتاج إنترنت": "Link analysis needs internet",
 "تم النسخ ✅": "Copied ✅",
 "تعذر النسخ: حدّد النص يدوياً": "Copy failed: select the text manually",
 "تعذر النسخ: حدّد النص من الخانات وانسخه يدوياً": "Copy failed: select the text from the fields and copy it manually",
 "أُلغي": "Cancelled",
 "حدث خطأ": "An error occurred",
 "⏳ بانتظار الإنترنت (اضغط للإلغاء)": "⏳ Waiting for internet (tap to cancel)",
 "🟢 أونلاين": "🟢 Online",
 "✈️ أوفلاين": "✈️ Offline",
 "🔴 بدون نت": "🔴 No internet",
 "وضع الأوفلاين: التقطيع والتصدير محلياً بدون إنترنت": "Offline mode: splitting and export run locally without internet",
 "رجعنا للوضع الأونلاين": "Back to online mode",
 "تقطيع رابط يوتيوب يحتاج إنترنت ومفتاح": "Splitting a YouTube link needs internet and a key",
 "⏹ إلغاء التقطيع": "⏹ Cancel splitting",
 "جارٍ تقطيع الفيديو إلى مشاهد…": "Splitting video into scenes…",
 "لم يتم العثور على مشاهد مناسبة": "No suitable scenes found",
 "انتهى التقطيع ✅": "Splitting finished ✅",
 "أُلغي التحليل المؤجل": "Deferred analysis cancelled",
 "ضع مفتاح Gemini داخل الكود (ملف src/config.js)": "Put your Gemini key in the code (src/config.js)",
 "أنت أوفلاين: هيتحلل تلقائياً أول ما النت يرجع ⏳": "You're offline: it will be analyzed automatically when the internet returns ⏳",
 "⏹ إلغاء التحليل": "⏹ Cancel analysis",
 "بانتظار عودتك للتطبيق لإكمال التحليل…": "Waiting for you to return to the app to finish the analysis…",
 "فشل التحليل": "Analysis failed",
 "تم كتابة العناوين والكابشن ✅": "Titles and captions written ✅",
 "انتهى التحليل ✅": "Analysis finished ✅",
 "العناوين والكابشن جاهزة": "Titles and captions are ready",
 "انقطع النت: هيكمّل تلقائياً لما يرجع ⏳": "Internet lost: it will continue automatically when it returns ⏳",
 "جارٍ تصدير المقطع (يستغرق بقدر مدة المقطع)…": "Exporting clip (takes about as long as the clip)…",
 "التصدير طلع فارغاً. جرّب فتح الصفحة في Chrome مباشرة.": "Export came out empty. Try opening the page directly in Chrome.",
 "فشل التصدير": "Export failed",
 "تم الحفظ في Documents/AlqfasReels ✅": "Saved to Documents/AlqfasReels ✅",
 "تم الحفظ ✅": "Saved ✅",
 "أُلغي الحفظ": "Save cancelled",
 "مشاركة المقطع": "Share clip",
 "أُلغي التحليل": "Analysis cancelled",
 "تعذر قراءة الفيديو": "Could not read the video",
 "انقطع الاتصال": "Connection lost",
 "انتهت مهلة الرفع": "Upload timed out",
 "الفيديو مرفوع مسبقاً، نكمل التحليل…": "Video already uploaded, continuing analysis…",
 "رفع الفيديو إلى Gemini…": "Uploading video to Gemini…",
 "Gemini يعالج الفيديو…": "Gemini is processing the video…",
 "تجهيز الفيديو…": "Preparing video…",
 "الذكاء الاصطناعي يحلل المشاهد…": "AI is analyzing the scenes…",
 "الذكاء الاصطناعي يكتب العناوين والكابشن…": "AI is writing titles and captions…",
 "Gemini يشاهد فيديو يوتيوب…": "Gemini is watching the YouTube video…",
 "Gemini يقرأ الرابط…": "Gemini is reading the link…",
 "Gemini يحلل الفيديو…": "Gemini is analyzing the video…",
 "فشلت معالجة الفيديو": "Video processing failed",
 "تعذر الحصول على رابط الرفع": "Could not get the upload link",
 "رد غير مفهوم من الذكاء الاصطناعي": "Unclear response from the AI",
 "تعذر معرفة مدة الفيديو": "Could not determine the video length",
 "تعذر فتح الفيديو للتصدير": "Could not open the video for export",
 "الجهاز لا يدعم التصدير": "This device does not support export",
 "جارٍ تلخيص الفيديو…": "Summarizing video…",
 "دمج الملخصات…": "Merging summaries…",
 "⏹ إلغاء التلخيص": "⏹ Cancel summary",
 "أُلغي التلخيص المؤجل": "Deferred summary cancelled",
 "⏳ بانتظار الإنترنت للتلخيص (اضغط للإلغاء)": "⏳ Waiting for internet to summarize (tap to cancel)",
 "أنت أوفلاين: هيتلخص تلقائياً أول ما النت يرجع ⏳": "You're offline: it will be summarized automatically when the internet returns ⏳",
 "تم تلخيص الفيديو ✅": "Video summarized ✅",
 "انتهى التلخيص ✅": "Summary finished ✅",
 "الملخص جاهز": "The summary is ready",
 "فشل التلخيص": "Summary failed"
};
const P = [
  [/^جارٍ تصدير المقطع (\d+) من (\d+)…$/, (m) => `Exporting clip ${m[1]} of ${m[2]}…`],
  [/^تم الضغط ✅ من ([\d.]+)MB إلى ([\d.]+)MB( — .*)?$/, (m) => `Compressed ✅ from ${m[1]}MB to ${m[2]}MB` + (m[3] ? ' — tap Save clip' : '')],
  [/^تم حفظ (\d+) مقطع في Documents\/AlqfasReels ✅$/, (m) => `Saved ${m[1]} clip(s) to Documents/AlqfasReels ✅`],
  [/^تمت الترجمة ✅ \((\d+) سطر\)$/, (m) => `Translated ✅ (${m[1]} lines)`],
  [/^جارٍ ترجمة الجزء (\d+) من (\d+)…$/, (m) => `Translating part ${m[1]} of ${m[2]}…`],
  [/^جارٍ ترجمة المقطع (\d+) من (\d+)…$/, (m) => `Translating clip ${m[1]} of ${m[2]}…`],
  [/^جارٍ التحميل (\d+)MB(?: من (\d+)MB)?$/, (m) => `Downloading ${m[1]}MB${m[2] ? ' of ' + m[2] + 'MB' : ''}`],
  [/^تم تقطيع الفيديو إلى (\d+) مشهد ✅( — اضغط .*)?$/, (m) => `Video split into ${m[1]} scenes ✅` + (m[2] ? ' — tap "AI analysis" if you want titles and captions (optional)' : '')],
  [/^تم استخراج (\d+) مشهد$/, (m) => `${m[1]} scenes extracted`],
  [/^تم التصدير ✅ حجم الملف ([\d.]+)MB — اضغط حفظ المقطع \(الكابشن منسوخ\)$/, (m) => `Exported ✅ file size ${m[1]}MB — tap Save clip (caption copied)`],
  [/^تعذر الحفظ: (.*)$/, (m) => 'Save failed: ' + tr(m[1])],
  [/^([\d.]+)ث$/, (m) => m[1] + 's'],
  [/^فشل بدء الرفع: (.*)$/, (m) => 'Upload start failed: ' + m[1]],
  [/^خطأ من Gemini: (.*)$/, (m) => 'Gemini error: ' + m[1]],
  [/^تلخيص الجزء (\d+) من (\d+)…$/, (m) => `Summarizing part ${m[1]} of ${m[2]}…`]
];

export function tr(s) {
  if (L.v !== 'en' || !s) return s;
  const t = String(s).trim();
  if (!t) return s;
  let o = D[t];
  if (o === undefined) for (const [re, f] of P) { const m = t.match(re); if (m) { o = f(m); break; } }
  if (o === undefined) return s;
  const i = s.indexOf(t);
  return s.slice(0, i) + o + s.slice(i + t.length);
}

const SKIP = new Set(['SCRIPT', 'STYLE', 'TEXTAREA']);
function tNode(n) {
  const p = n.parentNode;
  if (!p || SKIP.has(p.nodeName)) return;
  if (L.v === 'en') {
    if (n.__en === n.nodeValue) return;
    const o = tr(n.nodeValue);
    if (o !== n.nodeValue) { n.__ar = n.nodeValue; n.__en = o; n.nodeValue = o; }
  } else if (n.__en !== undefined) {
    if (n.nodeValue === n.__en) n.nodeValue = n.__ar;
    delete n.__en; delete n.__ar;
  }
}
function walk(root) {
  if (root.nodeType === 3) return tNode(root);
  const w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
  let n;
  while ((n = w.nextNode())) tNode(n);
}
function attrs() {
  document.querySelectorAll('[placeholder],[aria-label]').forEach((el) => {
    for (const a of ['placeholder', 'aria-label']) {
      if (!el.hasAttribute(a)) continue;
      el['__ar_' + a] = el['__ar_' + a] ?? el.getAttribute(a);
      el.setAttribute(a, L.v === 'en' ? tr(el['__ar_' + a]) : el['__ar_' + a]);
    }
  });
}
let ready = false;
export function setLang(l) {
  L.v = l;
  try { localStorage.setItem('lang', l); } catch {}
  const h = document.documentElement;
  h.lang = l; h.dir = l === 'en' ? 'ltr' : 'rtl';
  walk(h); attrs();
  const b = document.getElementById('btnLang');
  if (b) b.textContent = l === 'en' ? 'ع' : 'EN';
}
export function initI18n() {
  if (ready) return; ready = true;
  new MutationObserver((recs) => {
    for (const r of recs) {
      if (r.type === 'characterData') tNode(r.target);
      else r.addedNodes.forEach((n) => walk(n));
    }
  }).observe(document.documentElement, { subtree: true, childList: true, characterData: true });
  let l = 'ar';
  try { l = localStorage.getItem('lang') || 'ar'; } catch {}
  setLang(l);
}
