import './style.css';
import { Capacitor } from '@capacitor/core';
import { Filesystem, Directory } from '@capacitor/filesystem';
import { Share } from '@capacitor/share';
import { analyze, describeClips, analyzeLink, videoMeta, summarizeVideo, translateRanges } from './gemini.js';
import { L, tr, initI18n, setLang } from './i18n.js';
import { localAnalyze } from './local.js';
import { LocalNotifications } from '@capacitor/local-notifications';
import { Clipboard } from '@capacitor/clipboard';
import { GEMINI_API_KEY, GEMINI_MODEL } from './config.js';
import { exportClip, framesAt } from './clipper.js';
import { canNativeTrim, nativeTrim, nativeDownload, saveBlob, nativeCancel } from './native.js';

const $ = (id) => document.getElementById(id);
const store = {
  get: (k, d = '') => { try { return localStorage.getItem(k) ?? d; } catch { return d; } },
  set: (k, v) => { try { localStorage.setItem(k, v); } catch {} }
};
const S = { subs: [], id: null, out: null, blob: null, url: null, youtube: null, clips: [], active: -1, duration: 0, busy: false };
const video = $('video');
initI18n();
$('btnLang').onclick = () => setLang(L.v === 'en' ? 'ar' : 'en');

function status(msg, err = false) { const s = $('status'); s.textContent = msg; s.className = err ? 'err' : ''; }
function progress(p) { const b = $('bar'); b.hidden = p == null; if (p != null) b.firstElementChild.style.width = Math.round(p * 100) + '%'; }
const fmt = (t) => `${Math.floor(t / 60)}:${String(Math.floor(t % 60)).padStart(2, '0')}`;

function reset() {
  stopWatch(); S.out = null; S.pendingAI = false; $('result').hidden = true; $('btnAnalyze').hidden = true; $('btnAnalyze').textContent = AN_LABEL;
  S.clips = []; S.active = -1;
  $('strip').innerHTML = ''; $('details').hidden = true; $('btnExport').disabled = true; progress(null);
}

function loadBlob(blob, id = null) {
  if (S.url) URL.revokeObjectURL(S.url);
  reset();
  $('ytDur').hidden = true; $('linkInfo').hidden = true;
  $('sumBox').hidden = true; S.pendingSum = false; $('btnSummary').disabled = false; $('btnSummary').textContent = SUM_LABEL;
  S.subs = []; updSub(); $('btnTrClear').hidden = true; $('btnTranslate').disabled = false; $('btnTranslate').textContent = TR_LABEL; $('btnCompress').disabled = false; $('btnRun').disabled = false;
  S.blob = blob; S.id = id; S.youtube = null; S.url = URL.createObjectURL(blob);
  video.preload = 'metadata'; // أسرع في الفتح
  video.hidden = false; video.src = S.url; $('empty').style.display = 'none';
  video.onloadedmetadata = () => { S.duration = video.duration || 0; $('btnSplit').disabled = false; $('btnSplit').textContent = '✂️ تقطيع الفيديو إلى مشاهد'; status('جاهز للتقطيع'); };
}

function loadYoutube(url) {
  reset(); S.blob = null; S.url = null; S.id = null; S.youtube = url; S.duration = 0;
  video.removeAttribute('src'); video.load();
  $('empty').style.display = ''; $('empty').textContent = 'رابط يوتيوب: سيتم التحليل فقط (التصدير يحتاج ملف فيديو)';
  $('ytDur').hidden = false; $('linkInfo').hidden = true;
  $('sumBox').hidden = true; S.pendingSum = false; $('btnSummary').disabled = false; $('btnSummary').textContent = SUM_LABEL;
  S.subs = []; updSub(); $('btnTranslate').disabled = true; $('btnTrClear').hidden = true; $('btnCompress').disabled = true; $('btnRun').disabled = true;
  $('btnSplit').disabled = false; $('btnSplit').textContent = '✂️ تقطيع بالذكاء الاصطناعي (يوتيوب)'; status('جاهز للتقطيع');
}

$('file').onchange = (e) => {
  const f = e.target.files[0];
  if (f) loadBlob(f, `${f.name}:${f.size}:${f.lastModified}`);
};

async function fetchVideo(url) {
  status('جارٍ تحميل الفيديو…'); progress(0);
  if (Capacitor.isNativePlatform()) { // تحميل أصلي: بدون قيود CORS وبدون تحميل الملف كله في الذاكرة
    try {
      const raw = await nativeDownload(url, (got, total) => {
        progress(got / total);
        status(`جارٍ التحميل ${(got / 1048576).toFixed(0)}MB من ${(total / 1048576).toFixed(0)}MB`);
      });
      const ext = (url.match(/\.(mp4|webm|mov|m4v|mkv)(\?|#|$)/i) || [])[1] || 'mp4';
      const mime = { mp4: 'video/mp4', m4v: 'video/mp4', webm: 'video/webm', mov: 'video/quicktime', mkv: 'video/x-matroska' }[ext.toLowerCase()];
      loadBlob(new Blob([raw], { type: mime }));
      progress(null);
      return true;
    } catch { /* نجرب الطريقة العادية */ }
  }
  try {
    const r = await fetch(url);
    if (!r.ok) throw new Error();
    const total = +r.headers.get('content-length') || 0;
    const rd = r.body.getReader(), parts = [];
    let got = 0;
    for (;;) {
      const { done, value } = await rd.read();
      if (done) break;
      parts.push(value); got += value.length;
      if (total) progress(got / total);
      status(`جارٍ التحميل ${(got / 1048576).toFixed(0)}MB${total ? ' من ' + (total / 1048576).toFixed(0) + 'MB' : ''}`);
    }
    const type = r.headers.get('content-type') || '';
    loadBlob(new Blob(parts, { type: type.startsWith('video') ? type : 'video/mp4' }));
    progress(null);
    return true;
  } catch { progress(null); status('تعذر تحميل الرابط (قد يمنعه الموقع). حمّل الفيديو وارفعه من الجهاز.', true); return false; }
}

// تحليل الرابط: يوتيوب أو أي رابط => عنوان + وصف + هاشتاجات + كلمات مفتاحية
const URL_LABEL = '🔎 تحليل الرابط';
function showInfo(i) {
  $('iTitle').value = i.title; $('iDesc').value = i.description;
  $('iTags').value = i.hashtags.join(' '); $('iKeys').value = i.keywords.join('، ');
  $('linkInfo').hidden = false;
  $('linkInfo').scrollIntoView({ behavior: 'smooth', block: 'start' });
}
async function runLinkInfo(u, blob) {
  if (!hasKey()) return status('ضع مفتاح Gemini داخل الكود لتحليل الرابط (src/config.js)', true);
  const signal = startJob($('btnUrl'), '⏹ إلغاء');
  try {
    status('جارٍ تحليل الرابط…');
    const base = { key: GEMINI_API_KEY, model: GEMINI_MODEL, signal, onStatus: (m) => status(m), onProgress: (p) => progress(p) };
    showInfo(blob ? await videoMeta({ ...base, blob, cacheId: S.id }) : await analyzeLink({ ...base, url: u }));
    status('تم استخراج العنوان والوصف والهاشتاجات والكلمات المفتاحية ✅');
    if (document.hidden) notify('انتهى تحليل الرابط ✅', 'المعلومات جاهزة');
  } catch (e) { failMsg(e); }
  finally { endJob($('btnUrl'), URL_LABEL); }
}
$('btnUrl').onclick = async () => {
  if (job) { job.abort(); return; }
  const u = $('url').value.trim();
  if (!u) return;
  if (!isOnline()) return status('تحليل الرابط يحتاج إنترنت', true);
  if (/youtu\.?be/.test(u)) { loadYoutube(u); return runLinkInfo(u); }
  if (/\.(mp4|webm|mov|m4v|mkv)(\?|#|$)/i.test(u)) { // فيديو مباشر: نحمّله ونحلله
    if (await fetchVideo(u)) return runLinkInfo(u, S.blob);
    return;
  }
  return runLinkInfo(u); // رابط صفحة/منشور: نقرأه ونستخرج المعلومات
};
$('btnCopyInfo').onclick = async () => {
  const t = `${$('iTitle').value}\n\n${$('iDesc').value}\n\n${$('iTags').value}\n\nالكلمات المفتاحية: ${$('iKeys').value}`;
  status((await copyText(t)) ? 'تم النسخ ✅' : 'تعذر النسخ: حدّد النص يدوياً');
};

// ---- التحليل (غير حاجب للواجهة، قابل للإلغاء، يكمل لو خرجت من التطبيق) ----
const cache = {
  get: (id) => { try { return JSON.parse(localStorage.getItem('an:' + id) || 'null'); } catch { return null; } },
  set: (id, c) => { try { localStorage.setItem('an:' + id, JSON.stringify(c)); } catch {} }
};
let job = null, wakeLock = null;
const waitVisible = () => new Promise((res) => {
  if (!document.hidden) return res();
  const f = () => { if (!document.hidden) { document.removeEventListener('visibilitychange', f); res(); } };
  document.addEventListener('visibilitychange', f);
});
async function askNotify() {
  try {
    if (Capacitor.isNativePlatform()) await LocalNotifications.requestPermissions();
    else if ('Notification' in window && Notification.permission === 'default') Notification.requestPermission();
  } catch {}
}
async function notify(title, body) {
  title = tr(title); body = tr(body);
  try {
    if (Capacitor.isNativePlatform()) {
      const p = await LocalNotifications.checkPermissions();
      if (p.display === 'granted') await LocalNotifications.schedule({ notifications: [{ id: 1, title, body }] });
    } else if ('Notification' in window && Notification.permission === 'granted') new Notification(title, { body });
  } catch {}
}

function startJob(btn, label) {
  job = new AbortController(); btn.textContent = label; progress(0.02); askNotify();
  navigator.wakeLock?.request('screen').then((w) => { wakeLock = w; }).catch(() => {});
  return job.signal;
}
function endJob(btn, label) {
  job = null; btn.textContent = label; progress(null);
  try { wakeLock && wakeLock.release(); } catch {} wakeLock = null;
}
const failMsg = (e) => status(e.name === 'AbortError' ? 'أُلغي' : (e.message || 'حدث خطأ'), e.name !== 'AbortError');
const hasKey = () => GEMINI_API_KEY && !GEMINI_API_KEY.startsWith('ضع');
const SPLIT_LABEL = () => (S.youtube ? '✂️ تقطيع بالذكاء الاصطناعي (يوتيوب)' : '✂️ تقطيع الفيديو إلى مشاهد');
const AN_LABEL = '✨ تحليل بالذكاء الاصطناعي (اختياري)';
const SUM_LABEL = '📝 تلخيص الفيديو';
const PENDING_SUM = '⏳ بانتظار الإنترنت للتلخيص (اضغط للإلغاء)';
const PENDING_LABEL = '⏳ بانتظار الإنترنت (اضغط للإلغاء)';

// ---- وضع الإنترنت: يشتغل بدون نت، وبالنت يشتغل أوفلاين أو بالذكاء الاصطناعي ----
S.manualOffline = store.get('offline') === '1'; S.pendingAI = false;
const isOnline = () => navigator.onLine && !S.manualOffline;
function setPending() { S.pendingAI = true; $('btnAnalyze').textContent = PENDING_LABEL; }
function updateNet() {
  const on = isOnline();
  $('btnNet').textContent = on ? '🟢 أونلاين' : (S.manualOffline ? '✈️ أوفلاين' : '🔴 بدون نت');
  $('btnUrl').disabled = !on;
}
function onNet() {
  updateNet();
  if (isOnline() && S.pendingAI && S.clips.length && !job) { S.pendingAI = false; $('btnAnalyze').click(); }
  else if (isOnline() && S.pendingSum && (S.blob || S.youtube) && !job) { S.pendingSum = false; $('btnSummary').click(); }
}
$('btnNet').onclick = () => {
  S.manualOffline = !S.manualOffline; store.set('offline', S.manualOffline ? '1' : '0'); onNet();
  status(S.manualOffline ? 'وضع الأوفلاين: التقطيع والتصدير محلياً بدون إنترنت' : 'رجعنا للوضع الأونلاين');
};
window.addEventListener('online', onNet); window.addEventListener('offline', onNet);
updateNet();

// 1) تقطيع الفيديو إلى مشاهد (محلي، بدون إنترنت ولا مفتاح)
$('btnSplit').onclick = async () => {
  if (job) { job.abort(); return; }
  if (S.youtube) { // يوتيوب ما ينفع محلياً: نقطّعه بـ Gemini
    if (!hasKey() || !isOnline()) return status('تقطيع رابط يوتيوب يحتاج إنترنت ومفتاح', true);
    S.duration = (parseFloat($('ytDur').value) || 0) * 60;
  }
  reset();
  const signal = startJob($('btnSplit'), '⏹ إلغاء التقطيع');
  try {
    let clips;
    if (S.youtube) {
      clips = await analyze({ youtube: S.youtube, duration: S.duration, key: GEMINI_API_KEY, model: GEMINI_MODEL, onStatus: (m) => status(m), onProgress: (p) => progress(p), signal });
    } else {
      status('جارٍ تقطيع الفيديو إلى مشاهد…'); progress(0);
      clips = await localAnalyze(S.url, (p) => progress(p), signal);
    }
    if (!clips.length) throw new Error('لم يتم العثور على مشاهد مناسبة');
    S.clips = clips; renderStrip(); selectClip(0, false);
    $('btnAnalyze').hidden = S.youtube || !hasKey();
    status(`تم تقطيع الفيديو إلى ${clips.length} مشهد ✅` + (S.youtube ? '' : ' — اضغط "تحليل بالذكاء الاصطناعي" لو عايز عناوين وكابشن (اختياري)'));
    if (document.hidden) notify('انتهى التقطيع ✅', `تم استخراج ${clips.length} مشهد`);
    // كتابة العنوان والوصف تلقائياً بالذكاء الاصطناعي (أو تأجيلها لحد رجوع النت)
    if (!S.youtube && !S.pipe && hasKey()) { if (isOnline()) setTimeout(() => $('btnAnalyze').click(), 0); else setPending(); }
  } catch (e) { failMsg(e); }
  finally { endJob($('btnSplit'), SPLIT_LABEL()); }
};

// 2) تحليل اختياري بعد التقطيع: عنوان + كابشن + هاشتاجات لكل مشهد (الأوقات ما تتغير)
$('btnAnalyze').onclick = async () => {
  if (job) { job.abort(); return; }
  if (S.pendingAI) { S.pendingAI = false; $('btnAnalyze').textContent = AN_LABEL; return status('أُلغي التحليل المؤجل'); }
  if (!S.clips.length) return;
  if (!hasKey()) return status('ضع مفتاح Gemini داخل الكود (ملف src/config.js)', true);
  if (!isOnline()) { setPending(); return status('أنت أوفلاين: هيتحلل تلقائياً أول ما النت يرجع ⏳'); }
  const signal = startJob($('btnAnalyze'), '⏹ إلغاء التحليل');
  try {
    let res = null, err = null;
    for (let a = 0; a < 2 && !res; a++) {
      try {
        res = await describeClips({
          blob: S.blob, clips: S.clips, duration: S.duration, key: GEMINI_API_KEY, model: GEMINI_MODEL,
          onStatus: (m) => status(m), onProgress: (p) => progress(p), signal, cacheId: S.id
        });
      } catch (e) {
        if (e.name === 'AbortError') throw e;
        err = e;
        if (document.hidden && a === 0) { status('بانتظار عودتك للتطبيق لإكمال التحليل…'); await waitVisible(); continue; }
        break;
      }
    }
    if (!res) throw err || new Error('فشل التحليل');
    res.forEach((r) => {
      const c = S.clips[r.index];
      if (c) { c.title = r.title; c.caption = r.caption; c.hashtags = r.hashtags; c.reason = r.reason; }
    });
    selectClip(S.active < 0 ? 0 : S.active, false);
    status('تم كتابة العناوين والكابشن ✅');
    if (document.hidden) notify('انتهى التحليل ✅', 'العناوين والكابشن جاهزة');
  } catch (e) {
    if (e.name !== 'AbortError' && !navigator.onLine) { S.pendingAI = true; status('انقطع النت: هيكمّل تلقائياً لما يرجع ⏳'); }
    else failMsg(e);
  } finally { endJob($('btnAnalyze'), S.pendingAI ? PENDING_LABEL : AN_LABEL); }
};

// 3) تلخيص الفيديو (أي مدة، أي لغة) — الفيديوهات الطويلة تُلخَّص على أجزاء ثم تُدمج
function showSummary(r) {
  $('sSummary').value = r.summary;
  $('sPoints').value = r.keyPoints.map((p) => '• ' + p).join('\n');
  $('sChapters').value = r.chapters.map((c) => `${c.time}  ${c.title}`).join('\n');
  $('sumBox').hidden = false;
  $('sumBox').scrollIntoView({ behavior: 'smooth', block: 'start' });
}
$('btnSummary').onclick = async () => {
  if (job) { job.abort(); return; }
  if (S.pendingSum) { S.pendingSum = false; $('btnSummary').textContent = SUM_LABEL; return status('أُلغي التلخيص المؤجل'); }
  if (!S.blob && !S.youtube) return;
  if (!hasKey()) return status('ضع مفتاح Gemini داخل الكود (ملف src/config.js)', true);
  if (!isOnline()) { S.pendingSum = true; $('btnSummary').textContent = PENDING_SUM; return status('أنت أوفلاين: هيتلخص تلقائياً أول ما النت يرجع ⏳'); }
  if (S.youtube) S.duration = (parseFloat($('ytDur').value) || 0) * 60;
  const signal = startJob($('btnSummary'), '⏹ إلغاء التلخيص');
  try {
    let res = null, err = null;
    for (let a = 0; a < 2 && !res; a++) {
      try {
        res = await summarizeVideo({
          blob: S.blob, youtube: S.youtube, duration: S.duration, key: GEMINI_API_KEY, model: GEMINI_MODEL,
          onStatus: (m) => status(m), onProgress: (p) => progress(p), signal, cacheId: S.id,
          outLang: $('sumLang').value, len: $('sumLen').value
        });
      } catch (e) {
        if (e.name === 'AbortError') throw e;
        err = e;
        if (document.hidden && a === 0) { status('بانتظار عودتك للتطبيق لإكمال التحليل…'); await waitVisible(); continue; }
        break;
      }
    }
    if (!res) throw err || new Error('فشل التلخيص');
    showSummary(res);
    status('تم تلخيص الفيديو ✅');
    if (document.hidden) notify('انتهى التلخيص ✅', 'الملخص جاهز');
  } catch (e) {
    if (e.name !== 'AbortError' && !navigator.onLine) { S.pendingSum = true; status('انقطع النت: هيكمّل تلقائياً لما يرجع ⏳'); }
    else failMsg(e);
  } finally { endJob($('btnSummary'), S.pendingSum ? PENDING_SUM : SUM_LABEL); }
};
$('btnCopySum').onclick = async () => {
  const t = `${$('sSummary').value}\n\n${$('sPoints').value}\n\n${$('sChapters').value}`;
  status((await copyText(t)) ? 'تم النسخ ✅' : 'تعذر النسخ: حدّد النص يدوياً');
};


// 4) ترجمة الكلام (عربي ⇄ English) إلى ترجمة تظهر على الفيديو وتُحرق عند التصدير
const TR_LABEL = '🌐 ترجمة';
const subOv = $('subOverlay');
function updSub() {
  const t = video.currentTime || 0, c = S.subs.find((x) => t >= x.start && t < x.end);
  subOv.innerHTML = '';
  if (c) { const sp = document.createElement('span'); sp.textContent = c.text; sp.dir = 'auto'; subOv.appendChild(sp); }
}
let subRaf = 0;
function subLoop() { updSub(); if (!video.paused && !video.ended) subRaf = requestAnimationFrame(subLoop); }
video.addEventListener('play', () => { cancelAnimationFrame(subRaf); subLoop(); });
['pause', 'seeked', 'timeupdate', 'loadeddata'].forEach((ev) => video.addEventListener(ev, updSub));

// سطور الترجمة داخل نطاق مقطع (مطلقة) + نسبية لبداية المقطع (للتصدير الأصلي)
function cuesIn(a, b) {
  const abs = S.subs.filter((c) => c.end > a && c.start < b).map((c) => ({ start: Math.max(c.start, a), end: Math.min(c.end, b), text: c.text }));
  return { abs, rel: abs.map((c) => ({ s: +(c.start - a).toFixed(2), e: +(c.end - a).toFixed(2), t: c.text })) };
}

$('btnTranslate').onclick = async () => {
  if (job) { job.abort(); return; }
  if (!S.blob) return status('الترجمة تحتاج فيديو محمّل من الجهاز', true);
  if (!hasKey()) return status('ضع مفتاح Gemini داخل الكود (ملف src/config.js)', true);
  if (!isOnline()) return status('الترجمة تحتاج إنترنت', true);
  const scope = $('trScope').value;
  let ranges;
  if (scope === 'video') ranges = [[0, S.duration || video.duration || 0]];
  else if (scope === 'all') ranges = S.clips.map((c) => [c.start, c.end]);
  else if (S.active >= 0 && S.clips[S.active]) ranges = [[S.clips[S.active].start, S.clips[S.active].end]];
  if (!ranges || !ranges.length || ranges.some(([a, b]) => !(b > a))) return status('اختر مقطعاً أولاً (قطّع الفيديو ثم اضغط على مقطع)', true);
  const signal = startJob($('btnTranslate'), '⏹ إلغاء الترجمة');
  try {
    let fresh = [];
    for (let i = 0; i < ranges.length; i++) {
      if (ranges.length > 1) status(`جارٍ ترجمة المقطع ${i + 1} من ${ranges.length}…`);
      const part = await translateRanges({
        blob: S.blob, ranges: [ranges[i]], dir: $('trDir').value, key: GEMINI_API_KEY, model: GEMINI_MODEL, signal, cacheId: S.id,
        onStatus: (m) => status(m), onProgress: (p) => progress(((i + (p || 0)) / ranges.length))
      });
      fresh = fresh.concat(part);
    }
    // استبدال أي ترجمة قديمة داخل النطاقات المترجمة
    const keep = S.subs.filter((c) => !ranges.some(([a, b]) => c.end > a && c.start < b));
    S.subs = keep.concat(fresh).sort((x, y) => x.start - y.start);
    updSub();
    $('btnTrClear').hidden = !S.subs.length;
    status(fresh.length ? `تمت الترجمة ✅ (${fresh.length} سطر)` : 'لا يوجد كلام يمكن ترجمته');
    if (document.hidden) notify('انتهت الترجمة ✅', 'الترجمة جاهزة');
  } catch (e) { failMsg(e); }
  finally { endJob($('btnTranslate'), TR_LABEL); }
};
$('btnTrClear').onclick = () => { S.subs = []; updSub(); $('btnTrClear').hidden = true; status('تم مسح الترجمة'); };

function renderStrip() {
  const strip = $('strip'); strip.innerHTML = '';
  S.clips.forEach((c, i) => {
    const b = document.createElement('button');
    b.className = 'thumb';
    b.innerHTML = `<div class="img"><b>${i + 1}</b></div><small>${fmt(c.start)} – ${fmt(c.end)}</small>`;
    b.onclick = () => selectClip(i, true);
    strip.appendChild(b);
  });
  if (S.url) framesAt(S.url, S.clips.map((c) => c.start + 1), (i, d) => {
    strip.children[i].firstElementChild.style.backgroundImage = `url(${d})`;
  });
}

function selectClip(i, play) {
  S.active = i; S.out = null; $('result').hidden = true; const c = S.clips[i];
  [...$('strip').children].forEach((el, k) => el.classList.toggle('on', k === i));
  $('details').hidden = false;
  $('fTitle').value = c.title; $('fCaption').value = c.caption; $('fTags').value = c.hashtags.join(' ');
  $('btnExport').disabled = !S.blob;
  showTrim();
  if (S.blob) { video.currentTime = c.start; if (play) video.play().catch(() => {}); }
}

// إيقاف دقيق عند نهاية المقطع (كل إطار بدل timeupdate)
let raf = 0;
function stopWatch() { cancelAnimationFrame(raf); }
function watch() {
  stopWatch();
  const tick = () => {
    const c = S.clips[S.active];
    if (!c || video.paused) return;
    if (video.currentTime >= c.end - 0.03) { video.pause(); video.currentTime = c.end; return; }
    raf = requestAnimationFrame(tick);
  };
  raf = requestAnimationFrame(tick);
}
video.onplay = watch;
video.onpause = stopWatch;

// ضبط البداية والنهاية يدوياً
function showTrim() {
  const c = S.clips[S.active]; if (!c) return;
  $('tStart').textContent = c.start.toFixed(1) + 'ث'; $('tEnd').textContent = c.end.toFixed(1) + 'ث';
  const el = $('strip').children[S.active];
  if (el) el.querySelector('small').textContent = `${fmt(c.start)} – ${fmt(c.end)}`;
}
document.querySelectorAll('.trim button').forEach((b) => {
  b.onclick = () => {
    const c = S.clips[S.active]; if (!c) return;
    const k = b.dataset.k, d = parseFloat(b.dataset.d);
    const max = S.duration || Infinity;
    let v = Math.round((c[k] + d) * 10) / 10;
    if (k === 'start') v = Math.min(Math.max(0, v), c.end - 3);
    else v = Math.max(Math.min(v, max), c.start + 3);
    c[k] = v; showTrim();
    if (S.blob) { video.currentTime = k === 'start' ? c.start : Math.max(c.start, c.end - 2); video.play().catch(() => {}); }
  };
});
$('fTitle').oninput = (e) => { S.clips[S.active].title = e.target.value; };
$('fCaption').oninput = (e) => { S.clips[S.active].caption = e.target.value; };
$('fTags').oninput = (e) => { S.clips[S.active].hashtags = e.target.value.split(/\s+/).filter(Boolean); };

const fullText = (c) => `${c.title}\n\n${c.caption}\n\n${c.hashtags.join(' ')}`;
async function copyText(text) {
  try { if (Capacitor.isNativePlatform()) { await Clipboard.write({ string: text }); return true; } } catch {}
  try { if (navigator.clipboard && window.isSecureContext) { await navigator.clipboard.writeText(text); return true; } } catch {}
  try { // احتياطي يشتغل في WebView وملفات file://
    const t = document.createElement('textarea');
    t.value = text; t.setAttribute('readonly', '');
    t.style.cssText = 'position:fixed;top:0;left:0;opacity:0';
    document.body.appendChild(t); t.focus(); t.select(); t.setSelectionRange(0, text.length);
    const ok = document.execCommand('copy');
    t.remove();
    return ok;
  } catch { return false; }
}
$('btnCopy').onclick = async () => {
  const c = S.clips[S.active];
  if (!c) return;
  status((await copyText(fullText(c))) ? 'تم النسخ ✅' : 'تعذر النسخ: حدّد النص من الخانات وانسخه يدوياً', false);
};

// جودة/حجم التصدير: كل ما قلّ معدل البت والدقة قلّ الحجم
const QUAL = { high: { bitrate: 4e6, maxShort: 0 }, mid: { bitrate: 2e6, maxShort: 0 }, small: { bitrate: 1e6, maxShort: 480 } };
$('quality').value = store.get('q', 'mid');
$('quality').onchange = () => store.set('q', $('quality').value);

// ---- التصدير والمشاركة ----
// المشاركة تحتاج ضغطة مباشرة من المستخدم، لذلك بعد التصدير نعرض زرّي "مشاركة" و"حفظ"
const COMP = { hd: { bitrate: 3e6, maxShort: 720 }, sm: { bitrate: 1.2e6, maxShort: 480 }, xs: { bitrate: 6e5, maxShort: 360 } };

// يصنع ملف فيديو لنطاق (start→end) بالجودة q مع حرق الترجمة اختيارياً: قص أصلي سريع ثم احتياطي
async function makeClip({ start, end, name, q, burn }) {
  const sc = burn ? cuesIn(start, end) : { abs: [], rel: [] };
  const vmin = Math.min(video.videoWidth || 0, video.videoHeight || 0);
  const maxShort = q.maxShort && vmin > q.maxShort ? q.maxShort : 0; // لا نكبّر الدقة أبداً
  let bitrate = q.bitrate;
  if (S.blob && S.duration) bitrate = Math.max(3e5, Math.min(bitrate, (S.blob.size * 8 / S.duration) * 0.9)); // لا نزيد عن معدل الأصل
  let blob = null;
  if (canNativeTrim() && S.blob) {
    try {
      blob = await nativeTrim({ blob: S.blob, start, end, name: `${name}-${Date.now()}.mp4`, bitrate, maxShort, subs: sc.rel, vw: video.videoWidth, vh: video.videoHeight, onStatus: (m) => status(m), onProgress: progress });
    } catch (e) { console.warn('native trim failed', e); blob = null; status('القص السريع غير متاح، نستخدم التصدير العادي…'); }
  }
  if (!blob) {
    if (end - start > 120) status('التصدير العادي يستغرق بقدر مدة الفيديو…');
    progress(0);
    blob = await exportClip(S.url, start, end, progress, { bitrate, maxShort, subs: sc.abs });
  }
  if (!blob.size) throw new Error('التصدير طلع فارغاً. جرّب فتح الصفحة في Chrome مباشرة.');
  return blob;
}
const extOf = (blob) => (blob.type.includes('mp4') ? 'mp4' : 'webm');

$('btnExport').onclick = async () => {
  const c = S.clips[S.active];
  if (!c || !S.url || S.busy) return;
  S.busy = true; S.out = null; $('result').hidden = true; $('btnExport').disabled = true;
  try {
    status('جارٍ تصدير المقطع…'); progress(0);
    const blob = await makeClip({ start: c.start, end: c.end, name: `clip-${S.active + 1}`, q: QUAL[$('quality').value] || QUAL.mid, burn: $('trBurn').checked });
    S.out = { blob, name: `clip-${S.active + 1}.${extOf(blob)}`, c };
    await copyText(fullText(c));
    $('result').hidden = false;
    $('result').scrollIntoView({ behavior: 'smooth', block: 'center' });
    status(`تم التصدير ✅ حجم الملف ${(blob.size / 1048576).toFixed(1)}MB — اضغط حفظ المقطع (الكابشن منسوخ)`);
  } catch (e) { status(e.message || 'فشل التصدير', true); }
  finally { S.busy = false; $('btnExport').disabled = false; progress(null); }
};

// ضغط الفيديو كله (بالجودة المختارة) مع الترجمة لو موجودة
async function compressWhole(q, label) {
  const dur = S.duration || video.duration || 0;
  const blob = await makeClip({ start: 0, end: dur, name: label, q, burn: $('trBurn').checked });
  return blob;
}
$('btnCompress').onclick = async () => {
  if (!S.blob || !S.url || S.busy) return status('الفيديو يحتاج ملف على الجهاز للضغط والتصدير', true);
  S.busy = true; S.out = null; $('result').hidden = true; $('btnCompress').disabled = true;
  try {
    status('جارٍ ضغط الفيديو…'); progress(0);
    const blob = await compressWhole(COMP[$('compQ').value] || COMP.hd, 'compressed');
    S.out = { blob, name: `compressed-${Date.now()}.${extOf(blob)}`, c: { title: 'compressed', caption: '', hashtags: [] } };
    $('result').hidden = false;
    $('result').scrollIntoView({ behavior: 'smooth', block: 'center' });
    status(`تم الضغط ✅ من ${(S.blob.size / 1048576).toFixed(1)}MB إلى ${(blob.size / 1048576).toFixed(1)}MB — اضغط حفظ المقطع`);
  } catch (e) { status(e.message || 'فشل الضغط', true); }
  finally { S.busy = false; $('btnCompress').disabled = false; progress(null); }
};

// ---- تشغيل متعدد: اختر الخطوات (تقطيع / عناوين / ترجمة / تلخيص / تصدير / ضغط) ثم شغّلها بالترتيب ----
async function autoSave(blob, name) {
  if (Capacitor.isNativePlatform()) await saveBlob(blob, `AlqfasReels/${name}`);
  else download(blob, name);
}
$('pAll').onclick = () => ['pSplit', 'pAnalyze', 'pTr', 'pSum', 'pExp', 'pComp'].forEach((k) => { $(k).checked = true; });
$('pNone').onclick = () => ['pSplit', 'pAnalyze', 'pTr', 'pSum', 'pExp', 'pComp'].forEach((k) => { $(k).checked = false; });
const RUN_LABEL = '▶️ تشغيل الخطوات المحددة';
$('btnRun').onclick = async () => {
  if (S.pipe) { S.pipeCancel = true; if (job) job.abort(); nativeCancel(); return; }
  if (!S.blob) return status('اختر فيديو أولاً', true);
  const w = { split: $('pSplit').checked, analyze: $('pAnalyze').checked, tr: $('pTr').checked, sum: $('pSum').checked, exp: $('pExp').checked, comp: $('pComp').checked };
  if (!Object.values(w).some(Boolean)) return status('اختر خطوة واحدة على الأقل', true);
  S.pipe = true; S.pipeCancel = false; $('btnRun').textContent = '⏹ إيقاف التشغيل';
  let lock = null;
  try { lock = await navigator.wakeLock?.request('screen'); } catch {}
  const stop = () => S.pipeCancel;
  try {
    // الخطوات التي تحتاج مقاطع: نقطّع تلقائياً لو لم تُحدَّد خطوة التقطيع
    const needClips = w.analyze || w.exp || (w.tr && $('trScope').value !== 'video');
    if ((w.split || (needClips && !S.clips.length)) && !stop()) await $('btnSplit').onclick();
    if ((w.analyze || w.exp) && !S.clips.length) throw new Error('لم يتم العثور على مشاهد مناسبة');
    if (w.analyze && !stop()) await $('btnAnalyze').onclick();
    if (w.tr && !stop()) {
      if (!S.clips.length) $('trScope').value = 'video';
      await $('btnTranslate').onclick();
    }
    if (w.sum && !stop()) await $('btnSummary').onclick();
    let saved = 0;
    if (w.exp && !stop()) {
      const q = QUAL[$('quality').value] || QUAL.mid;
      for (let i = 0; i < S.clips.length && !stop(); i++) {
        const c = S.clips[i];
        status(`جارٍ تصدير المقطع ${i + 1} من ${S.clips.length}…`); progress(0);
        const blob = await makeClip({ start: c.start, end: c.end, name: `clip-${i + 1}`, q, burn: $('trBurn').checked });
        await autoSave(blob, `clip-${i + 1}-${Date.now()}.${extOf(blob)}`);
        saved++;
      }
    }
    if (w.comp && !stop()) {
      status('جارٍ ضغط الفيديو…'); progress(0);
      const blob = await compressWhole(COMP[$('compQ').value] || COMP.hd, 'compressed');
      await autoSave(blob, `compressed-${Date.now()}.${extOf(blob)}`);
      saved++;
    }
    if (stop()) status('تم إيقاف التشغيل');
    else if (saved) status(`تم حفظ ${saved} مقطع في Documents/AlqfasReels ✅`);
    else status('انتهى تشغيل الخطوات ✅');
    if (document.hidden && !stop()) notify('انتهى التشغيل ✅', 'اكتملت الخطوات المحددة');
  } catch (e) { status(e.message || 'فشل التشغيل', true); }
  finally {
    S.pipe = false; S.pipeCancel = false; $('btnRun').textContent = RUN_LABEL; progress(null);
    try { lock && lock.release(); } catch {}
  }
};

$('btnSave').onclick = async () => {
  if (!S.out) return;
  const { blob, name, c } = S.out;
  try {
    if (Capacitor.isNativePlatform()) {
      try {
        await saveBlob(blob, `AlqfasReels/${name}`);
        return status('تم الحفظ في Documents/AlqfasReels ✅');
      } catch { await shareBlob(blob, name, c); return status('تم الحفظ ✅'); } // احتياطي: نافذة النظام للحفظ
    }
    download(blob, name); status('تم الحفظ ✅');
  } catch (e) {
    if (e && e.name === 'AbortError') return status('أُلغي الحفظ');
    status('تعذر الحفظ: ' + (e.message || e.name), true);
  }
};

function download(blob, name) {
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob); a.download = name;
  document.body.appendChild(a); a.click(); a.remove();
}

async function shareBlob(blob, name, c) {
  if (Capacitor.isNativePlatform()) {
    const data = await new Promise((res, rej) => {
      const r = new FileReader(); r.onload = () => res(String(r.result).split(',')[1]); r.onerror = rej; r.readAsDataURL(blob);
    });
    await Filesystem.writeFile({ path: name, data, directory: Directory.Cache });
    const { uri } = await Filesystem.getUri({ path: name, directory: Directory.Cache });
    await Share.share({ title: c.title, text: fullText(c), files: [uri], dialogTitle: 'مشاركة المقطع' });
    return;
  }
  const file = new File([blob], name, { type: blob.type });
  if (navigator.canShare && navigator.canShare({ files: [file] })) {
    await navigator.share({ files: [file], title: c.title, text: fullText(c) });
  } else {
    download(blob, name);
  }
}
